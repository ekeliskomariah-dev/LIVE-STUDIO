package com.zack.livestudio.compositor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.Surface
import com.zack.livestudio.overlay.LayerModel
import com.zack.livestudio.overlay.LayerTransform
import com.zack.livestudio.overlay.LayerType
import com.zack.livestudio.util.AppLog
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * The compositor renders all scene layers into a single output surface
 * that is the encoder's input surface. This produces the final frame that
 * viewers will see in the live stream.
 *
 * Rendering pipeline per frame:
 *   1. Clear color buffer with background color
 *   2. For each layer in z-order (back-to-front):
 *      a. Upload the latest texture for that layer (camera, screen, browser, image, text)
 *      b. Draw a textured quad with the layer's transform
 *   3. Call eglSwapBuffers to push to the encoder input surface
 *
 * Camera & Screen layers feed their frames via SurfaceTexture (the
 * Surface provided to CameraX/MediaProjection). Browser, Image, and Text
 * layers are converted to Bitmap on the CPU side (rate-limited) and
 * uploaded as GL textures each frame.
 */
class SceneRenderer(
    private val context: Context
) : GLSurfaceView.Renderer,
    SurfaceTexture.OnFrameAvailableListener {

    private val lock = Any()
    private var layers: List<LayerModel> = emptyList()
    private var bgTextureHandle: Int = 0
    private var programHandle: Int = 0
    private var textureHandles = mutableMapOf<String, Int>()
    private var pendingBitmaps = mutableMapOf<String, Bitmap>()
    private var pendingSurfaces = mutableMapOf<String, SurfaceTexture>()
    private val mvpMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private var width: Int = 1280
    private var height: Int = 720

    var outputSurface: Surface? = null

    fun setLayers(sceneLayers: List<LayerModel>) {
        synchronized(lock) {
            layers = sceneLayers.sortedBy { it.zOrder }
            // Ensure textures exist for every layer
            for (layer in layers) {
                if (layer.id !in textureHandles && requiresTexture(layer.type)) {
                    val handles = IntArray(1)
                    GLES20.glGenTextures(1, handles, 0)
                    textureHandles[layer.id] = handles[0]
                    configureTexture(handles[0])
                }
            }
        }
    }

    fun setLayerBitmap(layerId: String, bitmap: Bitmap?) {
        if (bitmap == null) return
        synchronized(lock) { pendingBitmaps[layerId] = bitmap }
    }

    /**
     * Returns the SurfaceTexture for a camera/screen layer. The capture
     * pipeline writes its output surface from this texture.
     */
    fun obtainSurface(layerId: String, width: Int, height: Int): Surface {
        synchronized(lock) {
            val existing = pendingSurfaces[layerId]
            if (existing != null) return Surface(existing)
            val handles = IntArray(1)
            GLES20.glGenTextures(1, handles, 0)
            textureHandles[layerId] = handles[0]
            configureTexture(handles[0])
            val st = SurfaceTexture(handles[0])
            st.setDefaultBufferSize(width, height)
            st.setOnFrameAvailableListener(this)
            pendingSurfaces[layerId] = st
            return Surface(st)
        }
    }

    override fun onFrameAvailable(surfaceTexture: SurfaceTexture?) {
        // Just trigger a redraw — actual updateTextures() runs on GL thread
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        AppLog.i(TAG, "GL surface created")
        // Background fill is plain solid color — we draw it as a fullscreen quad with no texture
        val vertex = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            uniform mat4 uMVPMatrix;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = uMVPMatrix * aPosition;
                vTexCoord = aTexCoord;
            }
        """.trimIndent()
        val fragment = """
            precision mediump float;
            varying vec2 vTexCoord;
            uniform sampler2D uTexture;
            uniform float uOpacity;
            uniform vec4 uColor;
            uniform bool uUseTexture;
            void main() {
                if (uUseTexture) {
                    vec4 tex = texture2D(uTexture, vTexCoord);
                    gl_FragColor = vec4(tex.rgb, tex.a * uOpacity);
                } else {
                    gl_FragColor = vec4(uColor.rgb, uColor.a * uOpacity);
                }
            }
        """.trimIndent()
        programHandle = createProgram(vertex, fragment)
        Matrix.setIdentityM(projectionMatrix, 0)
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = w; height = h
        GLES20.glViewport(0, 0, w, h)
        // orthographic projection: screen-space pixels (0..w, 0..h) with origin bottom-left
        Matrix.orthoM(projectionMatrix, 0, 0f, w.toFloat(), 0f, h.toFloat(), -1f, 1f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        val layersToDraw: List<LayerModel>
        val bitmapsToUpload: Map<String, Bitmap>
        synchronized(lock) {
            // Update any pending SurfaceTextures
            for (st in pendingSurfaces.values) {
                try { st.updateTexImage() } catch (_: Exception) {}
            }
            layersToDraw = layers.filter { it.transform.visible }
            bitmapsToUpload = pendingBitmaps.toMap()
            pendingBitmaps.clear()
        }
        // Upload pending bitmaps
        for ((id, bmp) in bitmapsToUpload) {
            val handle = textureHandles[id] ?: continue
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, handle)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, bmp, 0)
            bmp.recycle()
        }

        if (programHandle == 0) return
        GLES20.glUseProgram(programHandle)
        val posHandle = GLES20.glGetAttribLocation(programHandle, "aPosition")
        val texHandle = GLES20.glGetAttribLocation(programHandle, "aTexCoord")
        val mvpHandle = GLES20.glGetUniformLocation(programHandle, "uMVPMatrix")
        val texSamplerHandle = GLES20.glGetUniformLocation(programHandle, "uTexture")
        val opacityHandle = GLES20.glGetUniformLocation(programHandle, "uOpacity")
        val colorHandle = GLES20.glGetUniformLocation(programHandle, "uColor")
        val useTextureHandle = GLES20.glGetUniformLocation(programHandle, "uUseTexture")

        for (layer in layersToDraw) {
            drawLayer(layer, posHandle, texHandle, mvpHandle, texSamplerHandle,
                opacityHandle, colorHandle, useTextureHandle)
        }
    }

    private fun drawLayer(
        layer: LayerModel,
        posHandle: Int,
        texHandle: Int,
        mvpHandle: Int,
        texSamplerHandle: Int,
        opacityHandle: Int,
        colorHandle: Int,
        useTextureHandle: Int
    ) {
        val t = layer.transform
        // Scene-space quad: x in [0, width], y in [0, height]
        val left = t.x * width
        val top = (1f - t.y - t.height) * height // flip Y so origin top-left
        val right = (t.x + t.width) * width
        val bottom = (1f - t.y) * height
        val centerX = (left + right) / 2f
        val centerY = (top + bottom) / 2f

        Matrix.setIdentityM(mvpMatrix, 0)
        Matrix.translateM(mvpMatrix, 0, centerX, centerY, 0f)
        if (t.rotationDeg != 0f) {
            Matrix.rotateM(mvpMatrix, 0, t.rotationDeg, 0f, 0f, 1f)
        }
        val halfW = (right - left) / 2f
        val halfH = (bottom - top) / 2f
        Matrix.scaleM(mvpMatrix, 0, halfW, halfH, 1f)

        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniform1f(opacityHandle, t.opacity)

        val hasTexture = textureHandles[layer.id] != null && requiresTexture(layer.type)
        if (hasTexture) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureHandles[layer.id] ?: return)
            GLES20.glUniform1i(texSamplerHandle, 0)
            GLES20.glUniform1i(useTextureHandle, 1)
        } else {
            // Solid color background — parse from LayerPayload.Background or default
            val color = when (val p = layer.payload) {
                is com.zack.livestudio.overlay.LayerPayload.Background -> parseColor(p.color)
                else -> floatArrayOf(0f, 0f, 0f, 1f)
            }
            GLES20.glUniform4f(colorHandle, color[0], color[1], color[2], color[3])
            GLES20.glUniform1i(useTextureHandle, 0)
        }

        // Quad vertices: position (x,y) + tex (u,v)
        val quad = floatArrayOf(
            -1f, -1f, 0f, 0f,
             1f, -1f, 1f, 0f,
            -1f,  1f, 0f, 1f,
             1f,  1f, 1f, 1f
        )
        val buffer = ByteBuffer
            .allocateDirect(quad.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        buffer.put(quad).position(0)

        // posHandle = vec2 (2 floats starting at offset 0, stride 16)
        buffer.position(0)
        GLES20.glEnableVertexAttribArray(posHandle)
        GLES20.glVertexAttribPointer(posHandle, 2, GLES20.GL_FLOAT, false, 16, buffer)

        buffer.position(2)
        GLES20.glEnableVertexAttribArray(texHandle)
        GLES20.glVertexAttribPointer(texHandle, 2, GLES20.GL_FLOAT, false, 16, buffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(posHandle)
        GLES20.glDisableVertexAttribArray(texHandle)
    }

    private fun configureTexture(handle: Int) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, handle)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private fun requiresTexture(type: LayerType): Boolean = type in setOf(
        LayerType.SCREEN, LayerType.CAMERA, LayerType.BROWSER,
        LayerType.IMAGE, LayerType.TEXT, LayerType.CHAT, LayerType.ALERT
    )

    private fun parseColor(hex: String): FloatArray {
        return try {
            val v = if (hex.startsWith("#")) hex.substring(1) else hex
            val r = v.substring(0, 2).toInt(16) / 255f
            val g = v.substring(2, 4).toInt(16) / 255f
            val b = v.substring(4, 6).toInt(16) / 255f
            val a = if (v.length >= 8) v.substring(6, 8).toInt(16) / 255f else 1f
            floatArrayOf(r, g, b, a)
        } catch (_: Exception) { floatArrayOf(0f, 0f, 0f, 1f) }
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        val vsh = compile(GLES20.GL_VERTEX_SHADER, vertex)
        if (vsh == 0) return 0
        val fsh = compile(GLES20.GL_FRAGMENT_SHADER, fragment)
        if (fsh == 0) return 0
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vsh)
        GLES20.glAttachShader(program, fsh)
        GLES20.glLinkProgram(program)
        val status = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] != GLES20.GL_TRUE) {
            AppLog.e(TAG, "Program link failed: ${GLES20.glGetProgramInfoLog(program)}")
            GLES20.glDeleteProgram(program)
            return 0
        }
        return program
    }

    private fun compile(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] != GLES20.GL_TRUE) {
            AppLog.e(TAG, "Shader compile failed: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    companion object { private const val TAG = "SceneRenderer" }
}
