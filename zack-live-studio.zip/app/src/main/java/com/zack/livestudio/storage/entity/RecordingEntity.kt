package com.zack.livestudio.storage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey val id: String,
    val filePath: String,
    val thumbnailPath: String?,
    val durationMs: Long,
    val sizeBytes: Long,
    val resolution: String,
    val fps: Int,
    val recordedAt: Long
)
