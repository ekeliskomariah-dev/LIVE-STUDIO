package com.zack.livestudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.zack.livestudio.R
import com.zack.livestudio.ui.components.GlassPanel
import com.zack.livestudio.ui.components.StatChip
import com.zack.livestudio.util.StreamStateBus

@Composable
fun StatsScreen(navController: NavController) {
    val state by StreamStateBus.state.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stream Statistics", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(0.dp)
        ) {
            item {
                GlassPanel(modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(12.dp)) {
                    Column {
                        StatChip(stringResource(R.string.stat_duration),
                            "${state.durationSec}s")
                        StatChip(stringResource(R.string.stat_fps),
                            state.fps.toInt().toString())
                        StatChip(stringResource(R.string.stat_bitrate),
                            "${state.bitrateKbps} kbps")
                        StatChip(stringResource(R.string.stat_dropped),
                            state.droppedFrames.toString())
                        StatChip("Reconnect count", state.reconnectCount.toString())
                        StatChip(stringResource(R.string.stat_cpu),
                            "${state.cpuPercent}%")
                        StatChip(stringResource(R.string.stat_ram),
                            "${state.ramPercent}%")
                        StatChip(stringResource(R.string.stat_temperature),
                            if (state.temperatureC > 0) "${state.temperatureC}°C" else "—")
                        StatChip(stringResource(R.string.stat_audio),
                            "${state.audioLevelDb} dB")
                    }
                }
            }
        }
    }
}
