package com.zack.livestudio.storage

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.zack.livestudio.storage.dao.ProfileDao
import com.zack.livestudio.storage.dao.SceneDao
import com.zack.livestudio.storage.dao.BrowserSourceDao
import com.zack.livestudio.storage.dao.RecordingDao
import com.zack.livestudio.storage.entity.ProfileEntity
import com.zack.livestudio.storage.entity.SceneEntity
import com.zack.livestudio.storage.entity.BrowserSourceEntity
import com.zack.livestudio.storage.entity.RecordingEntity

/**
 * Local Room database. Holds scenes, stream profiles, browser sources,
 * and recordings metadata. Stream keys themselves are NEVER stored here —
 * those live in [com.zack.livestudio.security.SecureStorage] keyed by
 * ProfileEntity.streamKeyRef.
 */
@Database(
    entities = [
        ProfileEntity::class,
        SceneEntity::class,
        BrowserSourceEntity::class,
        RecordingEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class ZackDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun sceneDao(): SceneDao
    abstract fun browserSourceDao(): BrowserSourceDao
    abstract fun recordingDao(): RecordingDao

    companion object {
        @Volatile private var INSTANCE: ZackDatabase? = null
        fun get(context: Context): ZackDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ZackDatabase::class.java,
                    "zack-studio.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

class Converters {
    @TypeConverter
    fun fromStringList(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        return value.split("|")
    }

    @TypeConverter
    fun toStringList(list: List<String>?): String {
        return list?.joinToString("|") ?: ""
    }

    @TypeConverter
    fun fromStringMap(value: String?): Map<String, String> {
        if (value.isNullOrBlank()) return emptyMap()
        return value.split(";").mapNotNull {
            val parts = it.split("=", limit = 2)
            if (parts.size == 2) parts[0] to parts[1] else null
        }.toMap()
    }

    @TypeConverter
    fun toStringMap(map: Map<String, String>?): String {
        return map?.entries?.joinToString(";") { "${it.key}=${it.value}" } ?: ""
    }
}
