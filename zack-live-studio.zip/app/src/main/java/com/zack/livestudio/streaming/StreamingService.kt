package com.zack.livestudio.streaming

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.zack.livestudio.MainActivity
import com.zack.livestudio.R
import com.zack.livestudio.ZackApp
import com.zack.livestudio.audio.AudioMixer
import com.zack.livestudio.audio.MicrophoneCapture
import com.zack.livestudio.capture.ScreenCapture
import com.zack.livestudio.compositor.SceneRenderer
import com.zack.livestudio.encoder.AudioEncoder
import com.zack.livestudio.encoder.VideoEncoder
import com.zack.livestudio.overlay.Scene
import com.zack.livestudio.security.SecureStorage
import com.zack.livestudio.streaming.rtmp.RtmpClient
import com.zack.livestudio.util.AppLog
import com.zack.livestudio.util.StreamStateBus
import com.zack.livestudio.util.SystemInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground service that owns the entire streaming pipeline while the
 * user is live:
 *
 *   SceneRenderer (GL surface) → VideoEncoder → RTMP packetizer → RtmpClient
 *   AudioMixer (mic + internal) → AudioEncoder → RTMP packetizer → RtmpClient
 *
 * The activity binds to the service via [LocalBinder] so the UI can issue
 * start/stop/pause/resume commands and read the live stats.
 *
 * The foreground service type is camera|microphone|mediaProjection so it
 * satisfies Android 14's strict service-type requirements.
 */
class StreamingService : Service() {

    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var rtmp: RtmpClient? = null
    private var videoEncoder: VideoEncoder? = null
    private var audioEncoder: AudioEncoder? = null
    private var audioMixer: AudioMixer? = null
    private var micCapture: MicrophoneCapture? = null
    private var screenCapture: ScreenCapture? = null
    private var renderer: SceneRenderer? = null
    private var statsJob: Job? = null
    private var reconnectJob: Job? = null

    private val running = AtomicBoolean(false)
    @Volatile private var paused = false
    @Volatile private var startedAt: Long = 0L

    inner class LocalBinder : Binder() { val service: StreamingService get() = this@StreamingService }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        AppLog.i(TAG, "Service created")
        screenCapture = ScreenCapture(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopStream()
            else -> Unit
        }
        return START_NOT_STICKY
    }

    fun startForegroundStream(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    fun buildNotification(): Notification {
        val state = StreamStateBus.state.value
        val builder = NotificationCompat.Builder(this, ZackApp.CHANNEL_STREAMING)
            .setSmallIcon(R.drawable.ic_stat_live)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(if (state.status == StreamStateBus.Status.LIVE) "LIVE • ${formatDuration(state.durationSec)}" else getString(R.string.status_connecting))
            .setSubText(getString(R.string.notif_streaming_format,
                "${state.bitrateKbps / 1000}.${(state.bitrateKbps % 1000) / 100} Mbps",
                state.fps.toInt(), state.bitrateKbps / 1000f))
            .setOngoing(true)
            .setColorized(true)
            .setColor(0xFFFF2D55.toInt())

        val openIntent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val openPi = PendingIntent.getActivity(this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        builder.addAction(R.drawable.ic_stat_live, getString(R.string.notif_action_open), openPi)

        val stopIntent = Intent(this, StreamingService::class.java).setAction(ACTION_STOP)
        val stopPi = PendingIntent.getService(this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        builder.addAction(R.drawable.ic_stat_live, getString(R.string.notif_action_stop), stopPi)

        builder.setContentIntent(openPi)
        return builder.build()
    }

    /**
     * Attempts to start a streaming session. Returns a Result with the
     * user-facing error message if anything fails.
     */
    fun startStream(
        profile: StreamProfile,
        scene: Scene,
        secure: SecureStorage
    ): Result<Unit> {
        if (running.get()) return Result.failure(IllegalStateException("Already streaming"))
        startedAt = SystemClock.elapsedRealtime()
        startForegroundStream(buildNotification())

        // 1. Load stream key
        val streamKey = secure.loadSecret(profile.streamKeyRef)
        if (streamKey.isNullOrBlank()) {
            StreamStateBus.update { it.copy(status = StreamStateBus.Status.ERROR,
                errorMessage = getString(R.string.error_invalid_stream_key)) }
            stopForeground(STOP_FOREGROUND_REMOVE)
            return Result.failure(IllegalStateException("Missing stream key"))
        }

        // 2. Connect RTMP
        StreamStateBus.update { it.copy(status = StreamStateBus.Status.CONNECTING) }
        val client = RtmpClient(profile.rtmpUrl, streamKey)
        return try {
            val handshake = client.connect()
            if (!handshake.success) {
                StreamStateBus.update { it.copy(status = StreamStateBus.Status.ERROR,
                    errorMessage = getString(R.string.error_rtmp_rejected)) }
                stopForeground(STOP_FOREGROUND_REMOVE)
                Result.failure(IllegalStateException(handshake.message))
            } else {
                rtmp = client
                running.set(true)
                StreamStateBus.update { it.copy(status = StreamStateBus.Status.LIVE) }
                startStatsJob()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            AppLog.e(TAG, "RTMP connect failed: ${e.message}")
            StreamStateBus.update { it.copy(status = StreamStateBus.Status.ERROR,
                errorMessage = e.message ?: getString(R.string.error_unknown)) }
            stopForeground(STOP_FOREGROUND_REMOVE)
            Result.failure(e)
        }
    }

    fun pauseStream() {
        if (!running.get()) return
        paused = true
        StreamStateBus.update { it.copy(status = StreamStateBus.Status.PAUSED) }
        // The encoder still receives frames but the RTMP writer is gated.
    }

    fun resumeStream() {
        if (!running.get()) return
        paused = false
        StreamStateBus.update { it.copy(status = StreamStateBus.Status.LIVE) }
        videoEncoder?.requestKeyframe()
    }

    fun stopStream() {
        if (!running.getAndSet(false)) return
        AppLog.i(TAG, "Stopping stream…")
        paused = false
        try { rtmp?.close() } catch (_: Exception) {}
        rtmp = null
        try { videoEncoder?.stop() } catch (_: Exception) {}
        try { audioEncoder?.stop() } catch (_: Exception) {}
        try { micCapture?.stop() } catch (_: Exception) {}
        videoEncoder = null
        audioEncoder = null
        audioMixer = null
        micCapture = null
        statsJob?.cancel(); statsJob = null
        reconnectJob?.cancel(); reconnectJob = null
        StreamStateBus.update { it.copy(status = StreamStateBus.Status.ENDED) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startStatsJob() {
        statsJob = scope.launch {
            while (running.get()) {
                val now = SystemClock.elapsedRealtime()
                val durationSec = (now - startedAt) / 1000
                StreamStateBus.update {
                    it.copy(
                        durationSec = durationSec,
                        cpuPercent = SystemInfo.cpuUsagePercent(),
                        ramPercent = SystemInfo.ramUsagePercent(this@StreamingService),
                        temperatureC = SystemInfo.batteryTemperatureC(this@StreamingService),
                        audioLevelDb = audioMixer?.outputLevelDb?.value ?: -100f
                    )
                }
                try {
                    val notif = buildNotification()
                    com.zack.livestudio.ui.NotificationHelper.notify(this@StreamingService, NOTIF_ID, notif)
                } catch (_: Exception) {}
                delay(1000L)
            }
        }
    }

    private fun formatDuration(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return String.format("%02d:%02d:%02d", h, m, s)
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        AppLog.i(TAG, "Service destroyed")
    }

    companion object {
        const val ACTION_STOP = "com.zack.livestudio.STOP"
        const val NOTIF_ID = 0x7AC1 // arbitrary stable notification id
        private const val TAG = "StreamingService"

        fun start(context: Context) {
            val intent = Intent(context, StreamingService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
