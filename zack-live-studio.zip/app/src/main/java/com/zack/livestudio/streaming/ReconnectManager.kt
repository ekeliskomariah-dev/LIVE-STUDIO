package com.zack.livestudio.streaming

import com.zack.livestudio.util.AppLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.pow

/**
 * Implements exponential backoff reconnect with jitter. Used by the
 * streaming service when the RTMP socket drops.
 *
 * Algorithm:
 *   - Wait: backoffSeconds = min(BASE * 2^attempt + jitter, MAX)
 *   - Retry: invoke reconnect callback
 *   - If retry succeeds: reset attempt counter
 *   - If retry fails: increment attempt, repeat
 *   - Stop after MAX_ATTEMPTS attempts OR if [cancel] is called
 *
 * The implementation never crashes the app on network failure — it only
 * reports progress through the [onStatus] callback so the UI can show
 * "Reconnecting…" status.
 */
class ReconnectManager(
    private val scope: CoroutineScope,
    private val maxAttempts: Int = 6,
    private val baseDelayMs: Long = 1_500L,
    private val maxDelayMs: Long = 30_000L,
    private val onStatus: (status: ReconnectStatus) -> Unit,
    private val tryReconnect: suspend () -> Boolean
) {
    sealed class ReconnectStatus {
        data class Waiting(val attempt: Int, val delayMs: Long) : ReconnectStatus()
        data class Attempting(val attempt: Int) : ReconnectStatus()
        data object Succeeded : ReconnectStatus()
        data object Failed : ReconnectStatus()
    }

    private var job: Job? = null
    @Volatile private var attempt = 0

    fun start() {
        cancel()
        job = scope.launch {
            attempt = 0
            while (attempt < maxAttempts) {
                val delayMs = min(maxDelayMs, (baseDelayMs * 2.0.pow(attempt.toDouble())).toLong()) +
                    (java.util.Random().nextInt(500))
                onStatus(ReconnectStatus.Waiting(attempt + 1, delayMs))
                AppLog.i(TAG, "Reconnect waiting ${delayMs}ms (attempt ${attempt + 1}/$maxAttempts)")
                delay(delayMs)
                onStatus(ReconnectStatus.Attempting(attempt + 1))
                val ok = try { tryReconnect() } catch (e: Exception) {
                    AppLog.w(TAG, "Reconnect attempt threw: ${e.message}")
                    false
                }
                if (ok) {
                    attempt = 0
                    onStatus(ReconnectStatus.Succeeded)
                    return@launch
                }
                attempt++
            }
            onStatus(ReconnectStatus.Failed)
            AppLog.w(TAG, "Reconnect failed after $maxAttempts attempts")
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        attempt = 0
    }

    companion object { private const val TAG = "ReconnectManager" }
}
