package com.zack.livestudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.zack.livestudio.R
import com.zack.livestudio.streaming.StreamConfig
import com.zack.livestudio.ui.components.GlassPanel

@Composable
fun SettingsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.nav_settings), fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp)
        ) {
            SectionTitle(stringResource(R.string.settings_performance_mode))
            GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                Column {
                    PerformanceModeOption(stringResource(R.string.settings_battery_saver),
                        StreamConfig.PerformanceMode.BATTERY_SAVER)
                    Spacer(Modifier.height(4.dp))
                    PerformanceModeOption(stringResource(R.string.settings_balanced),
                        StreamConfig.PerformanceMode.BALANCED)
                    Spacer(Modifier.height(4.dp))
                    PerformanceModeOption(stringResource(R.string.settings_performance),
                        StreamConfig.PerformanceMode.PERFORMANCE)
                }
            }

            Spacer(Modifier.height(16.dp))

            SectionTitle("Stream Profile")
            GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                Text("Tap to add a new RTMP profile",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.height(16.dp))

            SectionTitle("About")
            GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                Column {
                    Text("Zack Live Studio", fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface)
                    Text("Version 1.0.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text("RTMP streaming engine • H.264 hardware encoder • AAC audio",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(16.dp))

            SectionTitle(stringResource(R.string.settings_debug_log))
            GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                Text("Logs are stored at /data/data/com.zack.livestudio/files/logs/",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 8.dp))
}

@Composable
private fun PerformanceModeOption(label: String, mode: StreamConfig.PerformanceMode) {
    var selected by remember { mutableStateOf(mode == StreamConfig.PerformanceMode.BALANCED) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = { selected = true })
        Text(label, color = MaterialTheme.colorScheme.onSurface)
    }
}
