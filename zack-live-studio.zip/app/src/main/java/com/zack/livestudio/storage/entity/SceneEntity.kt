package com.zack.livestudio.storage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Scenes are stored as a serialized JSON blob of the [Scene] model. This
 * keeps the schema simple while allowing complex nested layer definitions.
 * The serialized format is validated by [SceneSerializer] tests.
 */
@Entity(tableName = "scenes")
data class SceneEntity(
    @PrimaryKey val id: String,
    val name: String,
    val json: String,
    val createdAt: Long,
    val updatedAt: Long
)
