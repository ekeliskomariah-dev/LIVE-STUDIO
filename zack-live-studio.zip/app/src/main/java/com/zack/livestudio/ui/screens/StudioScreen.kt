package com.zack.livestudio.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.zack.livestudio.R
import com.zack.livestudio.ui.components.GlassPanel
import com.zack.livestudio.ui.components.NeonGradientButton
import com.zack.livestudio.ui.components.StatChip
import com.zack.livestudio.ui.theme.LiveRed
import com.zack.livestudio.ui.theme.LiveGreen
import com.zack.livestudio.ui.theme.NeonBlue
import com.zack.livestudio.ui.theme.NeonPurple
import com.zack.livestudio.util.StreamStateBus
import androidx.compose.foundation.layout.fillMaxHeight

@Composable
fun StudioScreen(navController: NavController, vm: StudioViewModel = viewModel()) {
    val context = LocalContext.current
    val streamState by StreamStateBus.state.collectAsState()
    var showPermissionSheet by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Preview area — 9:16 portrait by default, with toggleable landscape 16:9
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(9f / 16f)
                    .background(Color.Black, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (streamState.status == StreamStateBus.Status.LIVE ||
                    streamState.status == StreamStateBus.Status.CONNECTING ||
                    streamState.status == StreamStateBus.Status.RECONNECTING
                ) {
                    // Live preview surface — the actual scene is rendered by the
                    // compositor inside the streaming service. The activity
                    // surface would be wired here in production.
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (streamState.status == StreamStateBus.Status.LIVE) "LIVE"
                                   else stringResource(R.string.status_connecting),
                            color = if (streamState.status == StreamStateBus.Status.LIVE) LiveRed else NeonBlue,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "${streamState.fps.toInt()} FPS • ${streamState.bitrateKbps / 1000} kbps",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    Text(
                        text = stringResource(R.string.status_idle),
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 16.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Stats chips row — horizontal scroll
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            item { StatChip(stringResource(R.string.stat_duration),
                formatDuration(streamState.durationSec), accent = NeonBlue) }
            item { StatChip(stringResource(R.string.stat_fps),
                streamState.fps.toInt().toString(), accent = NeonPurple) }
            item { StatChip(stringResource(R.string.stat_bitrate),
                "${streamState.bitrateKbps / 1000} kbps", accent = NeonBlue) }
            item { StatChip(stringResource(R.string.stat_dropped),
                streamState.droppedFrames.toString(), accent = LiveRed) }
            item { StatChip(stringResource(R.string.stat_cpu),
                "${streamState.cpuPercent}%", accent = NeonPurple) }
            item { StatChip(stringResource(R.string.stat_ram),
                "${streamState.ramPercent}%", accent = NeonBlue) }
            item { StatChip(stringResource(R.string.stat_temperature),
                if (streamState.temperatureC > 0) "${streamState.temperatureC.toInt()}°C" else "—",
                accent = if (streamState.temperatureC >= 42f) LiveRed else LiveGreen) }
            item { StatChip(stringResource(R.string.stat_audio),
                "${streamState.audioLevelDb.toInt()} dB", accent = NeonBlue) }
        }

        Spacer(Modifier.height(16.dp))

        // Quick source chips
        GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickSourceChip(Icons.Filled.ScreenShare, stringResource(R.string.layer_screen))
                QuickSourceChip(Icons.Filled.CameraAlt, stringResource(R.string.layer_camera))
                QuickSourceChip(Icons.Filled.Public, stringResource(R.string.layer_browser))
                QuickSourceChip(Icons.Filled.Image, stringResource(R.string.layer_image))
                QuickSourceChip(Icons.Filled.TextFields, stringResource(R.string.layer_text))
                QuickSourceChip(Icons.Filled.Mic, stringResource(R.string.audio_mic))
                QuickSourceChip(Icons.Filled.Movie, stringResource(R.string.start_recording))
            }
        }

        Spacer(Modifier.height(16.dp))

        // Start Live / Stop / Pause / Screenshot / Record
        GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
            Column {
                val isLive = streamState.status == StreamStateBus.Status.LIVE
                NeonGradientButton(
                    text = if (isLive) stringResource(R.string.stop_live) else stringResource(R.string.start_live),
                    isStop = isLive,
                    onClick = {
                        if (isLive) vm.stopStream(context)
                        else vm.startStream(context)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    androidx.compose.material3.TextButton(
                        onClick = { vm.togglePause(context) },
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Text(if (streamState.status == StreamStateBus.Status.PAUSED)
                            stringResource(R.string.resume_stream)
                            else stringResource(R.string.pause_stream),
                            color = NeonBlue)
                    }
                    androidx.compose.material3.TextButton(
                        onClick = { vm.takeScreenshot(context) }
                    ) {
                        Text(stringResource(R.string.take_screenshot), color = NeonPurple)
                    }
                    androidx.compose.material3.TextButton(
                        onClick = { vm.toggleRecording(context) }
                    ) {
                        Text(if (vm.recording.value) stringResource(R.string.stop_recording)
                             else stringResource(R.string.start_recording),
                             color = LiveRed)
                    }
                }
                if (streamState.errorMessage != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        streamState.errorMessage!!,
                        color = LiveRed,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiveRed.copy(alpha = 0.15f),
                                RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    )
                }
                if (streamState.safeModeReason != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Safe Mode: ${streamState.safeModeReason}",
                        color = MaterialTheme.colorScheme.tertiary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickSourceChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                RoundedCornerShape(10.dp))
            .padding(8.dp)
    ) {
        Icon(icon, contentDescription = label, tint = NeonBlue, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = MaterialTheme.colorScheme.onSurface, fontSize = 10.sp)
    }
}

private fun formatDuration(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}
