package com.zack.livestudio.storage.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.zack.livestudio.storage.entity.BrowserSourceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BrowserSourceDao {
    @Query("SELECT * FROM browser_sources ORDER BY lastUsedAt DESC")
    fun observeAll(): Flow<List<BrowserSourceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: BrowserSourceEntity)

    @Delete
    suspend fun delete(entity: BrowserSourceEntity)

    @Query("DELETE FROM browser_sources WHERE id = :id")
    suspend fun deleteById(id: String)
}
