package com.zack.livestudio.util

import android.content.Context
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicReference

/**
 * Lightweight logger that writes to logcat AND a rolling local file so
 * users can submit debug logs without requiring adb.
 */
object AppLog {

    private const val MAX_LOG_FILES = 5
    private val logDirRef = AtomicReference<File?>(null)
    private val tsFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    fun init(context: Context) {
        val dir = File(context.filesDir, "logs").apply { mkdirs() }
        logDirRef.set(dir)
        i("AppLog", "Logging initialized at ${dir.absolutePath}")
        trimOldLogs(dir)
    }

    private fun trimOldLogs(dir: File) {
        val files = dir.listFiles { f -> f.name.endsWith(".log") }
            ?.sortedByDescending { it.lastModified() }
            ?: return
        if (files.size > MAX_LOG_FILES) {
            files.drop(MAX_LOG_FILES).forEach { it.delete() }
        }
    }

    fun currentLogFile(): File? {
        val dir = logDirRef.get() ?: return null
        val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        return File(dir, "zack_$date.log").apply { if (!exists()) createNewFile() }
    }

    fun d(tag: String, msg: String) { write('D', tag, msg); Log.d(tag, msg) }
    fun i(tag: String, msg: String) { write('I', tag, msg); Log.i(tag, msg) }
    fun w(tag: String, msg: String, t: Throwable? = null) {
        write('W', tag, msg + (t?.let { "\n" + stackTrace(it) } ?: ""))
        Log.w(tag, msg, t)
    }
    fun e(tag: String, msg: String, t: Throwable? = null) {
        write('E', tag, msg + (t?.let { "\n" + stackTrace(it) } ?: ""))
        Log.e(tag, msg, t)
    }

    private fun write(level: Char, tag: String, msg: String) {
        val dir = logDirRef.get() ?: return
        val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val file = File(dir, "zack_$date.log")
        val line = "${tsFormat.format(Date())} $level/$tag: $msg\n"
        try {
            file.appendText(line)
        } catch (_: Exception) { /* swallow */ }
    }

    private fun stackTrace(t: Throwable): String {
        val sw = StringWriter()
        t.printStackTrace(PrintWriter(sw))
        return sw.toString()
    }
}
