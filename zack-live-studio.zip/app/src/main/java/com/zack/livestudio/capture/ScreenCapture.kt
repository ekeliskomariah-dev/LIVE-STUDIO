package com.zack.livestudio.capture

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.view.Surface
import androidx.core.content.getSystemService
import com.zack.livestudio.util.AppLog

/**
 * Thin wrapper around MediaProjection that handles launching the projection
 * intent, building the VirtualDisplay, and recovering from service disconnection.
 *
 * The captured frames are written to a Surface provided by the compositor
 * (a SurfaceTexture-backed GL texture). The MediaProjection API does not
 * support screenshot-based capture as a substitute; we use VirtualDisplay
 * which streams real Surface frames continuously.
 */
class ScreenCapture(private val context: Context) {

    private var projection: MediaProjection? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    @Volatile private var running = false

    fun mediaProjectionManager(): MediaProjectionManager? =
        context.getSystemService<MediaProjectionManager>()

    /**
     * Returns the Intent that the activity must launch via startActivityForResult
     * (or registerForActivityResult) to obtain a MediaProjection token.
     */
    fun createScreenCaptureIntent(): Intent {
        val mpm = mediaProjectionManager() ?: error("MediaProjectionManager unavailable")
        return mpm.createScreenCaptureIntent()
    }

    @Synchronized
    fun start(resultCode: Int, data: Intent, surface: Surface, width: Int, height: Int, dpi: Int): Boolean {
        if (running) {
            AppLog.w(TAG, "start() called while already running")
            return true
        }
        val mpm = mediaProjectionManager() ?: run {
            AppLog.e(TAG, "MediaProjectionManager null")
            return false
        }
        val mp = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                mpm.getMediaProjection(resultCode, data)
            } else {
                @Suppress("DEPRECATION")
                mpm.getMediaProjection(resultCode, data)
            }
        } catch (e: SecurityException) {
            AppLog.e(TAG, "MediaProjection denied: ${e.message}")
            return false
        } ?: run {
            AppLog.e(TAG, "MediaProjection token null")
            return false
        }
        projection = mp
        mp.registerCallback(callback, Handler(context.mainLooper))

        virtualDisplay = try {
            mp.createVirtualDisplay(
                "ZackLiveStudio-Screen",
                width, height, dpi,
                surface,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR
            )
        } catch (e: Exception) {
            AppLog.e(TAG, "createVirtualDisplay failed: ${e.message}")
            release()
            return false
        }
        running = true
        AppLog.i(TAG, "Screen capture started: ${width}x${height}@${dpi}dpi")
        return true
    }

    fun setSurface(surface: Surface) {
        try {
            virtualDisplay?.surface = surface
        } catch (e: Exception) {
            AppLog.w(TAG, "setSurface: ${e.message}")
        }
    }

    fun resize(width: Int, height: Int, dpi: Int) {
        virtualDisplay?.resize(width, height, dpi)
    }

    @Synchronized
    fun stop() {
        if (!running) return
        running = false
        release()
        AppLog.i(TAG, "Screen capture stopped")
    }

    private fun release() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            AppLog.w(TAG, "MediaProjection stopped")
            running = false
            release()
        }
    }

    companion object { private const val TAG = "ScreenCapture" }
}
