package com.zack.livestudio.encoder

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.view.Surface
import com.zack.livestudio.streaming.StreamConfig
import com.zack.livestudio.util.AppLog
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Hardware-accelerated H.264/AVC encoder using MediaCodec.
 *
 * The encoder takes input from a Surface (provided by the compositor) and
 * emits encoded NALU buffers via [onOutput] callback. The compositor owns
 * the EGL surface and feeds raw frames into it; MediaCodec turns them into
 * H.264 packets which are then wrapped as FLV tags by the RTMP pipeline.
 */
class VideoEncoder(
    private val config: StreamConfig,
    private val onOutput: (Sample) -> Unit
) {
    private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private val running = AtomicBoolean(false)
    private var thread: Thread? = null
    private var firstPtsUs = -1L

    fun isHardwareSupported(): Boolean {
        return try {
            for (type in MediaCodecListProvider.codecInfos()) {
                if (type.isHardwareAccelerated &&
                    type.supportedTypes.any { it.contains("avc") }) return true
            }
            false
        } catch (_: Exception) { false }
    }

    @Synchronized
    fun prepare(): Surface {
        if (codec != null) return inputSurface ?: error("Codec in bad state")
        val format = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_AVC,
            config.videoWidth,
            config.videoHeight
        ).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, config.videoBitrateKbps * 1000)
            setInteger(MediaFormat.KEY_FRAME_RATE, config.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, config.keyframeIntervalSec)
            setInteger(MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                setInteger(MediaFormat.KEY_PRIORITY, 0)
            }
        }

        // Try hardware first; fall back to software encoder.
        val codecList = MediaCodecListProvider.codecInfos()
        val hw = codecList.firstOrNull {
            it.isHardwareAccelerated && it.supportedTypes.any { t -> t.contains("avc") }
        }?.name
        val sw = codecList.firstOrNull {
            it.isSoftwareOnly && it.supportedTypes.any { t -> t.contains("avc") }
        }?.name
        val name = when {
            config.useHardwareEncoder && hw != null -> hw
            sw != null -> sw
            else -> MediaCodecListProvider.anyAvcEncoder() ?: "OMX.google.h264.encoder"
        }
        AppLog.i(TAG, "Creating video codec: $name")
        val c = MediaCodec.createByCodecName(name)
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = c.createInputSurface()
        codec = c
        inputSurface = surface
        return surface
    }

    fun start() {
        if (running.getAndSet(true)) return
        val c = codec ?: error("VideoEncoder not prepared")
        c.start()
        thread = Thread({ drainLoop() }, "VideoEncoder-Drain").apply { start() }
    }

    fun signalEndOfStream() {
        try {
            codec?.signalEndOfInputStream()
        } catch (e: Exception) {
            AppLog.w(TAG, "signalEndOfStream failed: ${e.message}")
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        codec = null
        try { inputSurface?.release() } catch (_: Exception) {}
        inputSurface = null
        thread?.join(500)
        thread = null
        firstPtsUs = -1L
    }

    fun requestKeyframe() {
        val c = codec ?: return
        try {
            val params = android.os.Bundle()
            params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            c.setParameters(params)
        } catch (e: Exception) {
            AppLog.w(TAG, "requestKeyframe failed: ${e.message}")
        }
    }

    private fun drainLoop() {
        val bufferInfo = MediaCodec.BufferInfo()
        val c = codec ?: return
        while (running.get()) {
            try {
                val outIndex = c.dequeueOutputBuffer(bufferInfo, 10_000L)
                if (outIndex >= 0) {
                    val buf: ByteBuffer = c.getOutputBuffer(outIndex) ?: continue
                    if (firstPtsUs < 0) firstPtsUs = bufferInfo.presentationTimeUs
                    if (bufferInfo.size > 0) {
                        val copy = ByteArray(bufferInfo.size)
                        buf.position(bufferInfo.offset)
                        buf.get(copy, 0, bufferInfo.size)
                        val ptsMs = (bufferInfo.presentationTimeUs - firstPtsUs) / 1000
                        onOutput(
                            Sample(
                                data = copy,
                                ptsMs = ptsMs.coerceAtLeast(0).toInt(),
                                isKeyframe = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0,
                                isConfig = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                            )
                        )
                    }
                    c.releaseOutputBuffer(outIndex, false)
                } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    Thread.sleep(2)
                }
            } catch (e: Exception) {
                if (running.get()) AppLog.w(TAG, "drain error: ${e.message}")
                break
            }
        }
    }

    data class Sample(
        val data: ByteArray,
        val ptsMs: Int,
        val isKeyframe: Boolean,
        val isConfig: Boolean
    )

    companion object {
        private const val TAG = "VideoEncoder"
    }
}
