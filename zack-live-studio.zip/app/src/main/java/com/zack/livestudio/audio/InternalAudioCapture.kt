package com.zack.livestudio.audio

import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import com.zack.livestudio.streaming.StreamConfig
import com.zack.livestudio.util.AppLog
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Captures system playback audio when supported (Android 10+) using
 * AudioPlaybackCaptureConfiguration. Requires a MediaProjection session
 * to be authorized by the user. If unsupported or denied, we surface a
 * clear error so the user can fall back to microphone-only mixing.
 */
class InternalAudioCapture(
    private val config: StreamConfig,
    private val onSamples: (ByteArray, Long) -> Unit
) {
    private var record: AudioRecord? = null
    private var thread: Thread? = null
    private val running = AtomicBoolean(false)

    /**
     * The MediaProjection must be authorized before calling this method.
     * Pass the result of `mp.createConfigForPlaybackCapture(...)` here.
     */
    fun prepare(projectionConfig: AudioPlaybackCaptureConfiguration): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            AppLog.w(TAG, "Internal audio capture needs Android 10+")
            return false
        }
        val minBuf = AudioRecord.getMinBufferSize(
            config.audioSampleRateHz,
            android.media.AudioFormat.CHANNEL_IN_STEREO,
            android.media.AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = (minBuf * 2).coerceAtLeast(8192)
        return try {
            val r = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.REMOTE_SUBMIX)
                .setAudioFormat(
                    android.media.AudioFormat.Builder()
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(config.audioSampleRateHz)
                        .setChannelMask(android.media.AudioFormat.CHANNEL_IN_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(bufSize)
                .setAudioPlaybackCaptureConfig(projectionConfig)
                .build()
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                AppLog.w(TAG, "Internal AudioRecord init failed")
                return false
            }
            record = r
            true
        } catch (e: Exception) {
            AppLog.w(TAG, "Internal audio unavailable: ${e.message}")
            false
        }
    }

    fun start() {
        val r = record ?: return
        if (running.getAndSet(true)) return
        try {
            r.startRecording()
        } catch (e: Exception) {
            AppLog.w(TAG, "Internal audio start failed: ${e.message}")
            running.set(false)
            return
        }
        thread = Thread({ loop(r) }, "InternalAudio-Loop").apply { start() }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null
        thread?.join(300)
        thread = null
    }

    private fun loop(r: AudioRecord) {
        val chunk = 2048
        val buf = ShortArray(chunk)
        while (running.get()) {
            val n = try { r.read(buf, 0, chunk) } catch (e: Exception) { break }
            if (n <= 0) continue
            val bytes = ByteArray(n * 2)
            ByteBuffer.wrap(bytes).asShortBuffer().put(buf, 0, n)
            onSamples(bytes, System.nanoTime() / 1000)
        }
    }

    companion object { private const val TAG = "InternalAudioCapture" }
}
