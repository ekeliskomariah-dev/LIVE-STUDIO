package com.zack.livestudio.streaming.rtmp

/**
 * AMF0 encoder. Produces the byte payloads used by RTMP command messages
 * like `connect`, `createStream`, `publish`.
 *
 * Spec: AMF0 specification (Adobe), used by virtually every RTMP server.
 */
class AmfEncoder {
    private val out = java.io.ByteArrayOutputStream()

    fun bytes(): ByteArray = out.toByteArray()

    fun writeNumber(value: Double): AmfEncoder {
        out.write(AMF0_NUMBER)
        val bits = java.lang.Double.doubleToLongBits(value)
        for (i in 7 downTo 0) out.write(((bits ushr (i * 8)) and 0xFF).toInt())
        return this
    }

    fun writeBoolean(value: Boolean): AmfEncoder {
        out.write(AMF0_BOOLEAN)
        out.write(if (value) 1 else 0)
        return this
    }

    fun writeString(value: String): AmfEncoder {
        out.write(AMF0_STRING)
        val bytes = value.toByteArray(Charsets.UTF_8)
        out.write((bytes.size ushr 8) and 0xFF)
        out.write(bytes.size and 0xFF)
        out.write(bytes)
        return this
    }

    fun writeNull(): AmfEncoder {
        out.write(AMF0_NULL)
        return this
    }

    fun beginObject(): AmfEncoder {
        out.write(AMF0_OBJECT)
        return this
    }

    fun writeName(name: String): AmfEncoder {
        val bytes = name.toByteArray(Charsets.UTF_8)
        out.write((bytes.size ushr 8) and 0xFF)
        out.write(bytes.size and 0xFF)
        out.write(bytes)
        return this
    }

    fun endObject(): AmfEncoder {
        out.write(0); out.write(0); out.write(AMF0_OBJECT_END)
        return this
    }

    fun beginEcmaArray(): AmfEncoder {
        out.write(AMF0_ECMA_ARRAY)
        out.write(0); out.write(0); out.write(0); out.write(0) // length placeholder
        return this
    }

    fun writeRawBytes(bytes: ByteArray): AmfEncoder {
        out.write(bytes)
        return this
    }

    companion object {
        const val AMF0_NUMBER = 0x00
        const val AMF0_BOOLEAN = 0x01
        const val AMF0_STRING = 0x02
        const val AMF0_OBJECT = 0x03
        const val AMF0_NULL = 0x05
        const val AMF0_UNDEFINED = 0x06
        const val AMF0_OBJECT_END = 0x09
        const val AMF0_ECMA_ARRAY = 0x08
        const val AMF0_STRICT_ARRAY = 0x0A
    }
}

/**
 * Minimal AMF0 decoder used to parse the RTMP `_result` for connect/createStream.
 */
class AmfDecoder(private val data: ByteArray) {
    private var pos = 0

    fun decodeAll(): List<Any?> {
        val list = mutableListOf<Any?>()
        while (pos < data.size) {
            val v = decodeValue() ?: break
            list.add(v)
        }
        return list
    }

    private fun readByte(): Int {
        if (pos >= data.size) return -1
        return data[pos++].toInt() and 0xFF
    }

    private fun readShort(): Int {
        val hi = readByte(); val lo = readByte()
        return (hi shl 8) or lo
    }

    private fun readDouble(): Double {
        val bits = (0..7).fold(0L) { acc, i -> (acc shl 8) or readByte().toLong() }
        return java.lang.Double.longBitsToDouble(bits)
    }

    private fun readString(): String {
        val len = readShort()
        val sb = StringBuilder(len)
        for (i in 0 until len) sb.append((readByte()).toChar())
        return sb.toString()
    }

    private fun decodeValue(): Any? {
        val marker = readByte()
        if (marker == -1) return null
        return when (marker) {
            AmfEncoder.AMF0_NUMBER -> readDouble()
            AmfEncoder.AMF0_BOOLEAN -> readByte() != 0
            AmfEncoder.AMF0_STRING -> readString()
            AmfEncoder.AMF0_NULL, AmfEncoder.AMF0_UNDEFINED -> null
            AmfEncoder.AMF0_OBJECT -> decodeObject()
            AmfEncoder.AMF0_ECMA_ARRAY -> {
                // skip 4-byte length
                readByte(); readByte(); readByte(); readByte()
                decodeObject()
            }
            else -> null
        }
    }

    private fun decodeObject(): Map<String, Any?> {
        val map = LinkedHashMap<String, Any?>()
        while (true) {
            val nameLen = readShort()
            if (nameLen == 0) {
                val endMarker = readByte()
                if (endMarker == AmfEncoder.AMF0_OBJECT_END) break
                continue
            }
            val name = StringBuilder(nameLen)
            for (i in 0 until nameLen) name.append(readByte().toChar())
            val value = decodeValue()
            map[name.toString()] = value
        }
        return map
    }
}
