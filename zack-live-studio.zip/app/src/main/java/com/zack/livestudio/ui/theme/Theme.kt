package com.zack.livestudio.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import android.os.Build

// Zack Live Studio — dark premium palette
val NeonBlue = Color(0xFF3D7BFF)
val NeonPurple = Color(0xFF8E54FF)
val NeonCyan = Color(0xFF22E5FF)
val LiveRed = Color(0xFFFF2D55)
val LiveGreen = Color(0xFF34D17C)
val Amber = Color(0xFFFFB340)
val DeepNavy = Color(0xFF05071A)
val PanelColor = Color(0xFF0D0F1F)
val PanelAltColor = Color(0xFF14162A)
val CardColor = Color(0xFF1A1D33)
val TextPrimary = Color(0xFFF6F8FF)
val TextSecondary = Color(0xFFB9BECC)
val TextTertiary = Color(0xFF7A8194)
val DividerColor = Color(0xFF1F2238)
val StrokeGlass = Color(0xFF2A2D45)

private val ZackDarkScheme = darkColorScheme(
    primary = NeonBlue,
    onPrimary = Color.White,
    primaryContainer = CardColor,
    onPrimaryContainer = TextPrimary,
    secondary = NeonPurple,
    onSecondary = Color.White,
    secondaryContainer = PanelAltColor,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonCyan,
    onTertiary = Color.Black,
    tertiaryContainer = PanelColor,
    onTertiaryContainer = TextPrimary,
    error = LiveRed,
    onError = Color.White,
    background = DeepNavy,
    onBackground = TextPrimary,
    surface = PanelColor,
    onSurface = TextPrimary,
    surfaceVariant = CardColor,
    onSurfaceVariant = TextSecondary,
    outline = StrokeGlass,
    outlineVariant = DividerColor,
    scrim = Color(0x99000000),
    inverseSurface = CardColor,
    inverseOnSurface = TextPrimary,
    inversePrimary = NeonBlue,
)

@Composable
fun ZackLiveStudioTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val scheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        else -> ZackDarkScheme
    }
    MaterialTheme(
        colorScheme = scheme,
        content = content
    )
}
