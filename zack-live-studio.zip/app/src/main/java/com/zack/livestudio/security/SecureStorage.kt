package com.zack.livestudio.security

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.zack.livestudio.util.AppLog
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Secrets storage built on AndroidKeystore + EncryptedSharedPreferences.
 *
 * Stream keys, OAuth tokens, and other secrets are stored here and ONLY
 * accessed at the moment a live session begins. They are never written
 * to AppLog, never appear in crash reports, and are wiped on logout.
 *
 * The encryption uses AES-GCM with hardware-backed keys when available.
 */
class SecureStorage private constructor(
    private val prefs: SharedPreferences
) {
    fun saveSecret(referenceId: String, value: String) {
        try {
            prefs.edit().putString(referenceId, value).apply()
        } catch (e: Exception) {
            AppLog.e(TAG, "saveSecret failed for $referenceId: ${e.message}")
        }
    }

    fun loadSecret(referenceId: String): String? {
        return try { prefs.getString(referenceId, null) } catch (_: Exception) { null }
    }

    fun deleteSecret(referenceId: String) {
        try { prefs.edit().remove(referenceId).apply() } catch (_: Exception) {}
    }

    fun hasSecret(referenceId: String): Boolean =
        try { prefs.contains(referenceId) } catch (_: Exception) { false }

    companion object {
        private const val TAG = "SecureStorage"
        private const val PREF_FILE_NAME = "zack_secure.xml"
        private const val KEYSTORE_ALIAS = "zack_live_studio_master_key"

        fun get(context: Context): SecureStorage {
            val masterKey = try {
                MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .setKeyGenParameterSpec(
                        KeyGenParameterSpec.Builder(
                            KEYSTORE_ALIAS,
                            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                        )
                            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                            .setKeySize(256)
                            .build()
                    )
                    .build()
            } catch (e: Exception) {
                AppLog.e(TAG, "MasterKey creation failed, falling back: ${e.message}")
                // Fallback to a master key alias that lets EncryptedSharedPreferences handle it
                MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
            }
            val prefs = EncryptedSharedPreferences.create(
                context,
                PREF_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            return SecureStorage(prefs)
        }

        // Diagnostic helper used by tests / debug menu only
        fun isHardwareBacked(): Boolean {
            return try {
                val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                val entry = ks.getEntry(KEYSTORE_ALIAS, null)
                entry is KeyStore.SecretKeyEntry
            } catch (_: Exception) { false }
        }
    }
}
