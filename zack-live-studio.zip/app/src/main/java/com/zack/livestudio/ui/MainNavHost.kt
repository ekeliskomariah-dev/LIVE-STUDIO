package com.zack.livestudio.ui

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.zack.livestudio.R
import com.zack.livestudio.ui.screens.ChatScreen
import com.zack.livestudio.ui.screens.LoadingScreen
import com.zack.livestudio.ui.screens.RecordingsScreen
import com.zack.livestudio.ui.screens.ScenesScreen
import com.zack.livestudio.ui.screens.SettingsScreen
import com.zack.livestudio.ui.screens.SourcesScreen
import com.zack.livestudio.ui.screens.StatsScreen
import com.zack.livestudio.ui.screens.StudioScreen

object Routes {
    const val LOADING = "loading"
    const val STUDIO = "studio"
    const val SCENES = "scenes"
    const val SOURCES = "sources"
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val STATS = "stats"
    const val RECORDINGS = "recordings"
}

private data class BottomItem(val route: String, val label: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun MainNavHost() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: Routes.STUDIO

    val bottomItems = listOf(
        BottomItem(Routes.STUDIO, R.string.nav_studio, Icons.Filled.PlayCircle),
        BottomItem(Routes.SCENES, R.string.nav_scenes, Icons.Filled.Movie),
        BottomItem(Routes.CHAT, R.string.nav_chat, Icons.Filled.Chat),
        BottomItem(Routes.SETTINGS, R.string.nav_settings, Icons.Filled.Settings)
    )
    val showBottomBar = currentRoute in bottomItems.map { it.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(Routes.STUDIO) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(stringResource(item.label)) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.STUDIO,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.STUDIO) { StudioScreen(navController) }
            composable(Routes.SCENES) { ScenesScreen(navController) }
            composable(Routes.SOURCES) { SourcesScreen(navController) }
            composable(Routes.CHAT) { ChatScreen(navController) }
            composable(Routes.SETTINGS) { SettingsScreen(navController) }
            composable(Routes.STATS) { StatsScreen(navController) }
            composable(Routes.RECORDINGS) { RecordingsScreen(navController) }
        }
    }
}
