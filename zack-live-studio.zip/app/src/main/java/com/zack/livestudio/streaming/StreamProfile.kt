package com.zack.livestudio.streaming

/**
 * A single RTMP destination. The stream key is held in-memory only and is
 * loaded from [com.zack.livestudio.security.SecureStorage] at the moment
 * a live session begins. NEVER persist stream keys in plaintext, NEVER log
 * them to logcat or AppLog.
 */
data class StreamProfile(
    val id: String,
    val name: String,
    val platform: Platform,
    val rtmpUrl: String,
    val streamKeyRef: String,         // reference id used by SecureStorage
    val config: StreamConfig,
    val createdAt: Long,
    val updatedAt: Long
) {
    enum class Platform(val displayName: String) {
        YOUTUBE("YouTube"),
        TWITCH("Twitch"),
        TIKTOK("TikTok"),
        CUSTOM_RTMP("Custom RTMP");

        companion object {
            fun defaultRtmpUrl(platform: Platform): String = when (platform) {
                YOUTUBE -> "rtmp://a.rtmp.youtube.com/live2"
                TWITCH -> "rtmp://live.twitch.tv/app"
                TIKTOK -> "rtmp://push.tiktokcdn.com/live" // user must verify
                CUSTOM_RTMP -> ""
            }
        }
    }
}
