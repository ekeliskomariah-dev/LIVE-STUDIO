package com.zack.livestudio

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.zack.livestudio.storage.ZackDatabase
import com.zack.livestudio.util.AppLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Application entry point. Bootstraps logging, notification channels,
 * and the local database. Heavy work is deferred to lazy initialization
 * in [StreamingService] so cold start stays fast.
 */
class ZackApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database: ZackDatabase by lazy { ZackDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        AppLog.init(this)
        AppLog.i("ZackApp", "Application starting")
        applicationScope.launch {
            createNotificationChannels()
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_STREAMING,
                getString(R.string.notif_channel_streaming),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notif_channel_streaming_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_STREAMING = "zack.streaming"

        @Volatile
        private var instance: ZackApp? = null

        fun get(): ZackApp = instance ?: error("ZackApp not initialized")
    }
}
