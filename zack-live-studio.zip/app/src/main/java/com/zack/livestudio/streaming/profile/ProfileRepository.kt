package com.zack.livestudio.streaming.profile

import android.content.Context
import com.zack.livestudio.security.SecureStorage
import com.zack.livestudio.storage.ZackDatabase
import com.zack.livestudio.storage.entity.ProfileEntity
import com.zack.livestudio.streaming.StreamConfig
import com.zack.livestudio.streaming.StreamProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Repository that bridges [StreamProfile] domain objects with the Room
 * [ProfileEntity] storage layer. Stream keys themselves are routed through
 * [SecureStorage] so they never appear in Room or logcat.
 */
class ProfileRepository(context: Context) {

    private val dao = ZackDatabase.get(context).profileDao()
    private val secure = SecureStorage.get(context)

    fun observeAll(): Flow<List<StreamProfile>> = dao.observeAll().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun save(profile: StreamProfile, streamKey: String?) {
        dao.upsert(profile.toEntity())
        if (streamKey != null) secure.saveSecret(profile.streamKeyRef, streamKey)
    }

    suspend fun delete(id: String) {
        // Look up entity to find streamKeyRef before deleting
        val entity = dao.findById(id) ?: return
        secure.deleteSecret(entity.streamKeyRef)
        dao.deleteById(id)
    }

    suspend fun loadStreamKey(profile: StreamProfile): String? {
        return secure.loadSecret(profile.streamKeyRef)
    }

    private fun StreamProfile.toEntity(): ProfileEntity = ProfileEntity(
        id = id,
        name = name,
        platform = platform.name,
        rtmpUrl = rtmpUrl,
        streamKeyRef = streamKeyRef,
        resolution = "${config.videoWidth}x${config.videoHeight}",
        fps = config.fps,
        bitrateKbps = config.videoBitrateKbps,
        audioBitrateKbps = config.audioBitrateKbps,
        performanceMode = config.performanceMode.name,
        preset = config.preset.name,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun ProfileEntity.toDomain(): StreamProfile {
        val (w, h) = resolution.split("x").let {
            (it.getOrNull(0)?.toIntOrNull() ?: 1280) to (it.getOrNull(1)?.toIntOrNull() ?: 720)
        }
        val cfg = StreamConfig(
            videoWidth = w, videoHeight = h,
            fps = fps,
            videoBitrateKbps = bitrateKbps,
            audioBitrateKbps = audioBitrateKbps,
            performanceMode = runCatching {
                StreamConfig.PerformanceMode.valueOf(performanceMode)
            }.getOrDefault(StreamConfig.PerformanceMode.BALANCED),
            preset = runCatching { StreamConfig.Preset.valueOf(preset) }
                .getOrDefault(StreamConfig.Preset.BALANCED)
        )
        val plat = runCatching { StreamProfile.Platform.valueOf(platform) }
            .getOrDefault(StreamProfile.Platform.CUSTOM_RTMP)
        return StreamProfile(
            id = id, name = name, platform = plat,
            rtmpUrl = rtmpUrl, streamKeyRef = streamKeyRef,
            config = cfg, createdAt = createdAt, updatedAt = updatedAt
        )
    }
}

object ProfileFactory {
    fun newYoutube(name: String = "YouTube Live"): StreamProfile {
        val ref = "yt_${UUID.randomUUID()}"
        return StreamProfile(
            id = UUID.randomUUID().toString(),
            name = name,
            platform = StreamProfile.Platform.YOUTUBE,
            rtmpUrl = StreamProfile.Platform.defaultRtmpUrl(StreamProfile.Platform.YOUTUBE),
            streamKeyRef = ref,
            config = StreamConfig.fromPreset(StreamConfig.Preset.BALANCED,
                StreamConfig.PerformanceMode.BALANCED),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun newTwitch(name: String = "Twitch"): StreamProfile {
        val ref = "tw_${UUID.randomUUID()}"
        return StreamProfile(
            id = UUID.randomUUID().toString(),
            name = name,
            platform = StreamProfile.Platform.TWITCH,
            rtmpUrl = StreamProfile.Platform.defaultRtmpUrl(StreamProfile.Platform.TWITCH),
            streamKeyRef = ref,
            config = StreamConfig.fromPreset(StreamConfig.Preset.BALANCED,
                StreamConfig.PerformanceMode.BALANCED),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun newCustom(name: String, rtmpUrl: String): StreamProfile {
        val ref = "cs_${UUID.randomUUID()}"
        return StreamProfile(
            id = UUID.randomUUID().toString(),
            name = name,
            platform = StreamProfile.Platform.CUSTOM_RTMP,
            rtmpUrl = rtmpUrl,
            streamKeyRef = ref,
            config = StreamConfig.fromPreset(StreamConfig.Preset.BALANCED,
                StreamConfig.PerformanceMode.BALANCED),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
    }
}
