package com.zack.livestudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.zack.livestudio.ui.MainNavHost
import com.zack.livestudio.ui.theme.ZackLiveStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZackLiveStudioTheme {
                MainNavHost()
            }
        }
        splash.setKeepOnScreenCondition { false }
    }
}
