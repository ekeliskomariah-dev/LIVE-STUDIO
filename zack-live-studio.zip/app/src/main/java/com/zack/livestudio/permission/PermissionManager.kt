package com.zack.livestudio.permission

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

/**
 * Permission state tracked by the UI so we can show explanatory text
 * before requesting permission, and offer "Open Settings" if the user
 * permanently denies.
 */
enum class PermState { GRANTED, SHOULD_REQUEST, PERMANENTLY_DENIED }

data class PermissionRequest(
    val title: String,
    val message: String,
    val permissions: Array<String>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PermissionRequest) return false
        return permissions.contentEquals(other.permissions) && title == other.title
    }
    override fun hashCode(): Int = 31 * title.hashCode() + permissions.contentHashCode()
}

object PermissionManager {

    fun isGranted(context: Context, permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED
    }

    fun isGranted(context: Context, permissions: Array<String>): Boolean {
        return permissions.all { isGranted(context, it) }
    }

    fun shouldRequestCamera(context: Context): Boolean =
        !isGranted(context, android.Manifest.permission.CAMERA)

    fun shouldRequestMic(context: Context): Boolean =
        !isGranted(context, android.Manifest.permission.RECORD_AUDIO)

    fun shouldRequestNotifications(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return false
        return !isGranted(context, android.Manifest.permission.POST_NOTIFICATIONS)
    }

    fun shouldRequestMedia(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            !isGranted(context, arrayOf(
                android.Manifest.permission.READ_MEDIA_IMAGES,
                android.Manifest.permission.READ_MEDIA_VIDEO
            ))
        } else {
            !isGranted(context, android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
}

/**
 * Compose helper that requests a single runtime permission with a
 * launcher. Returns whether the permission is currently granted.
 */
@Composable
fun rememberPermissionGranted(
    permission: String
): Boolean {
    val context = androidx.compose.ui.platform.LocalContext.current
    var granted by remember(permission) {
        mutableStateOf(PermissionManager.isGranted(context, permission))
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { result -> granted = result }
    LaunchedEffect(permission) {
        if (!granted) launcher.launch(permission)
    }
    return granted
}
