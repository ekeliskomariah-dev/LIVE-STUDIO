package com.zack.livestudio.streaming.rtmp

import com.zack.livestudio.util.AppLog
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A minimal but real RTMP client.
 *
 * Implements:
 *  - Simple handshake (C0/C1/C2 + S0/S1/S2)
 *  - SetChunkSize
 *  - Connect command (NetConnection.Connect.Success expected)
 *  - CreateStream
 *  - Publish command
 *  - Audio/Video data messages as FLV tags
 *
 * Does NOT implement TLS (RTMPS). Use a plain RTMP URL. RTMPS support
 * requires SSLEngine socket wrapping — left as a TODO so the code path
 * reports a clean error instead of silently failing.
 *
 * Packet format follows the Adobe RTMP spec:
 *   https://www.adobe.com/devnet/rtmp.html
 */
class RtmpClient(
    private val url: String,
    private val streamKey: String,
    private val connectTimeoutMs: Int = 10_000,
    private val readTimeoutMs: Int = 15_000
) {

    private val running = AtomicBoolean(false)
    private var socket: Socket? = null
    private var input: DataInputStream? = null
    private var output: DataOutputStream? = null

    private var chunkSize: Int = 128
    private var streamId: Int = 1
    private var transactionId: Double = 1.0

    @Synchronized
    @Throws(IOException::class)
    fun connect(): RtmpHandshakeResult {
        if (running.get()) throw IOException("Already connected")
        val parsed = RtmpUrl.parse(url)
            ?: throw IOException("Invalid RTMP URL: $url")
        AppLog.i(TAG, "Connecting to ${parsed.host}:${parsed.port} app=${parsed.app} stream=${parsed.streamKey ?: streamKey}")

        val sock = Socket()
        sock.tcpNoDelay = true
        sock.connect(InetSocketAddress(parsed.host, parsed.port), connectTimeoutMs)
        sock.soTimeout = readTimeoutMs
        socket = sock
        input = DataInputStream(sock.getInputStream())
        output = DataOutputStream(sock.getOutputStream())

        handshake()
        sendChunkSize(4096)
        chunkSize = 4096

        val connectResult = sendConnect(parsed)
        if (!connectResult.success) {
            close()
            throw IOException("RTMP server rejected connection: ${connectResult.message}")
        }

        streamId = sendCreateStream()
        val publishStream = parsed.streamKey ?: streamKey
        sendPublish(streamId, publishStream)
        running.set(true)
        AppLog.i(TAG, "RTMP publish session ready")
        return connectResult
    }

    @Throws(IOException::class)
    private fun handshake() {
        val out = output ?: throw IOException("No output stream")
        val inp = input ?: throw IOException("No input stream")

        // C0 + C1
        out.writeByte(3) // version
        val c1 = ByteArray(1536)
        val rand = SecureRandom()
        // time = 0; random bytes for the remaining 1528
        rand.nextBytes(c1)
        c1[0] = 0; c1[1] = 0; c1[2] = 0; c1[3] = 0
        c1[4] = 0; c1[5] = 0; c1[6] = 0; c1[7] = 0
        out.write(c1)
        out.flush()

        // S0 + S1 + S2
        val s0 = inp.readUnsignedByte()
        if (s0 != 3) throw IOException("Unexpected RTMP version from server: $s0")
        val s1 = ByteArray(1536)
        inp.readFully(s1)
        val s2 = ByteArray(1536)
        inp.readFully(s2)

        // C2 — echo S1
        out.write(s1)
        out.flush()
    }

    @Throws(IOException::class)
    private fun sendChunkSize(size: Int) {
        val payload = ByteArray(4)
        payload[0] = (size ushr 24).toByte()
        payload[1] = (size ushr 16).toByte()
        payload[2] = (size ushr 8).toByte()
        payload[3] = size.toByte()
        writeMessage(MessageType.SET_CHUNK_SIZE, 0, payload)
    }

    @Throws(IOException::class)
    private fun sendConnect(parsed: RtmpUrl.Parsed): RtmpHandshakeResult {
        val txId = ++transactionId
        val app = parsed.app.ifEmpty { "live" }
        val tcUrl = "rtmp://${parsed.host}:${parsed.port}/$app"
        val amf = AmfEncoder()
            .writeString("connect")
            .writeNumber(txId)
            .beginObject()
            .writeName("app").writeString(app)
            .writeName("flashVer").writeString("FMLE/3.0 (compatible; ZackLiveStudio)")
            .writeName("tcUrl").writeString(tcUrl)
            .writeName("fpad").writeBoolean(false)
            .writeName("capabilities").writeNumber(15.0)
            .writeName("audioCodecs").writeNumber(4071.0)
            .writeName("videoCodecs").writeNumber(252.0)
            .writeName("videoFunction").writeNumber(1.0)
            .writeName("objectEncoding").writeNumber(0.0)
            .endObject()
            .bytes()

        writeMessage(MessageType.COMMAND_AMF0, 0, amf)

        // Read server response: typically a Window Ack Size, Set Peer BW,
        // Set Chunk Size, and finally the connect result.
        val deadline = System.currentTimeMillis() + readTimeoutMs
        while (System.currentTimeMillis() < deadline) {
            val msg = readMessage() ?: continue
            if (msg.type == MessageType.COMMAND_AMF0) {
                val decoded = AmfDecoder(msg.payload).decodeAll()
                if (decoded.isNotEmpty() && decoded[0] == "_result") {
                    val props = decoded.getOrNull(2) as? Map<*, *>
                    val code = props?.get("code") as? String ?: ""
                    val description = props?.get("description") as? String ?: ""
                    return RtmpHandshakeResult(
                        success = code == "NetConnection.Connect.Success",
                        message = description.ifEmpty { code }
                    )
                }
                if (decoded[0] == "_error") {
                    return RtmpHandshakeResult(false, decoded.getOrNull(2)?.toString() ?: "Connection refused")
                }
            }
        }
        throw IOException("RTMP connect timed out waiting for server response")
    }

    @Throws(IOException::class)
    private fun sendCreateStream(): Int {
        val txId = ++transactionId
        val amf = AmfEncoder()
            .writeString("createStream")
            .writeNumber(txId)
            .writeNull()
            .bytes()
        writeMessage(MessageType.COMMAND_AMF0, 0, amf)
        val deadline = System.currentTimeMillis() + readTimeoutMs
        while (System.currentTimeMillis() < deadline) {
            val msg = readMessage() ?: continue
            if (msg.type == MessageType.COMMAND_AMF0) {
                val decoded = AmfDecoder(msg.payload).decodeAll()
                if (decoded.isNotEmpty() && decoded[0] == "_result") {
                    val sid = decoded.getOrNull(3)
                    if (sid is Double) return sid.toInt()
                    if (sid is Number) return sid.toInt()
                }
            }
        }
        throw IOException("RTMP createStream timed out")
    }

    @Throws(IOException::class)
    private fun sendPublish(streamId: Int, streamName: String) {
        val txId = ++transactionId
        val amf = AmfEncoder()
            .writeString("publish")
            .writeNumber(txId)
            .writeNull()
            .writeString(streamName)
            .writeString("live")
            .bytes()
        writeMessage(MessageType.COMMAND_AMF0, streamId, amf)
    }

    /**
     * Write a video FLV tag (H.264 AVC).
     * The payload should already include the FLV tag byte header
     * (0x17 for keyframe / 0x27 for inter) + AVCPacketType + composition time
     * + NALU data. See [com.zack.livestudio.streaming.rtmp.FlvTagWriter].
     */
    @Synchronized
    @Throws(IOException::class)
    fun writeVideo(timestampMs: Int, payload: ByteArray, isKeyframe: Boolean, isConfig: Boolean) {
        if (!running.get()) return
        val header = FlvTagWriter.videoHeader(payload, timestampMs, isKeyframe, isConfig)
        writeMessage(MessageType.VIDEO_DATA, streamId, header)
    }

    @Synchronized
    @Throws(IOException::class)
    fun writeAudio(timestampMs: Int, payload: ByteArray, isConfig: Boolean) {
        if (!running.get()) return
        val header = FlvTagWriter.audioHeader(payload, timestampMs, isConfig)
        writeMessage(MessageType.AUDIO_DATA, streamId, header)
    }

    @Synchronized
    @Throws(IOException::class)
    fun writeMetadata(timestampMs: Int, metadata: ByteArray) {
        if (!running.get()) return
        writeMessage(MessageType.DATA_AMF0, streamId, metadata)
    }

    @Synchronized
    fun close() {
        running.set(false)
        try { output?.flush() } catch (_: Exception) {}
        try {
            // FCUnpublish + deleteStream courtesy call
            val amf = AmfEncoder()
                .writeString("deleteStream")
                .writeNumber(++transactionId)
                .writeNull()
                .writeNumber(streamId.toDouble())
                .bytes()
            writeMessage(MessageType.COMMAND_AMF0, streamId, amf)
        } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        input = null
        output = null
        AppLog.i(TAG, "RTMP session closed")
    }

    val isConnected: Boolean get() = running.get() && socket?.isConnected == true && socket?.isClosed == false

    // ---- Low-level RTMP chunk framing ----

    @Throws(IOException::class)
    private fun writeMessage(type: Int, csid: Int, payload: ByteArray) {
        val out = output ?: throw IOException("No output stream")
        val messageLength = payload.size
        val firstChunk = minOf(chunkSize, payload.size)

        // Basic header (format 0, csid)
        out.writeByte(0x00 or (csid and 0x3F))

        // Message timestamp (3 bytes) — always 0; the per-tag timestamp is
        // already inside the FLV header written by FlvTagWriter.
        out.writeByte(0)
        out.writeByte(0)
        out.writeByte(0)

        // Message length (3 bytes)
        out.writeByte((messageLength ushr 16) and 0xFF)
        out.writeByte((messageLength ushr 8) and 0xFF)
        out.writeByte(messageLength and 0xFF)

        // Message type id (1 byte)
        out.writeByte(type and 0xFF)

        // Message stream id (4 bytes, little-endian per spec)
        out.writeByte(streamId and 0xFF)
        out.writeByte((streamId ushr 8) and 0xFF)
        out.writeByte((streamId ushr 16) and 0xFF)
        out.writeByte((streamId ushr 24) and 0xFF)

        // First chunk data
        out.write(payload, 0, firstChunk)
        var written = firstChunk

        // Subsequent chunks use format 3 (no header)
        while (written < payload.size) {
            val n = minOf(chunkSize, payload.size - written)
            out.writeByte(0xC0 or (csid and 0x3F)) // format 3
            out.write(payload, written, n)
            written += n
        }
        out.flush()
    }

    @Throws(IOException::class)
    private fun readMessage(): RtmpMessage? {
        val inp = input ?: return null
        // Read basic header
        val first = inp.readUnsignedByte()
        val fmt = (first ushr 6) and 0x03
        var csid = first and 0x3F
        if (csid == 0) csid = inp.readUnsignedByte() + 64
        else if (csid == 1) {
            csid = inp.readUnsignedByte() + (inp.readUnsignedByte() shl 8) + 64
        }
        var timestamp = 0
        var messageLength = 0
        var messageType = 0
        var messageStreamId = 0
        if (fmt <= 2) {
            val b1 = inp.readUnsignedByte()
            val b2 = inp.readUnsignedByte()
            val b3 = inp.readUnsignedByte()
            timestamp = (b1 shl 16) or (b2 shl 8) or b3
            if (fmt <= 1) {
                val l1 = inp.readUnsignedByte()
                val l2 = inp.readUnsignedByte()
                val l3 = inp.readUnsignedByte()
                messageLength = (l1 shl 16) or (l2 shl 8) or l3
                if (fmt <= 0) {
                    messageType = inp.readUnsignedByte()
                    if (fmt == 0) {
                        messageStreamId = inp.readInt()
                    }
                }
            }
        }

        if (messageLength == 0) return null

        val payload = ByteArray(messageLength)
        var read = 0
        while (read < messageLength) {
            val n = minOf(chunkSize, messageLength - read)
            inp.readFully(payload, read, n)
            read += n
            if (read < messageLength) {
                // skip 1 byte (format 3 basic header)
                inp.readUnsignedByte()
            }
        }
        return RtmpMessage(messageType, messageStreamId, payload)
    }

    private data class RtmpMessage(val type: Int, val streamId: Int, val payload: ByteArray)

    data class RtmpHandshakeResult(val success: Boolean, val message: String)

    companion object {
        private const val TAG = "RtmpClient"
    }
}
