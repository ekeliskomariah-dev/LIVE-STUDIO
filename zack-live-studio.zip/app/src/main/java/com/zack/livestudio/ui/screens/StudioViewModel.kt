package com.zack.livestudio.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zack.livestudio.security.SecureStorage
import com.zack.livestudio.streaming.StreamProfile
import com.zack.livestudio.streaming.StreamingService
import com.zack.livestudio.util.AppLog
import com.zack.livestudio.util.StreamStateBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Backing state for the Studio screen. Owns the link to the StreamingService
 * (which is a foreground service) and exposes actions to the UI.
 *
 * The actual encoder/RTMP/compositor work happens inside the service; this
 * ViewModel only orchestrates intents, status reads, and errors.
 */
class StudioViewModel : ViewModel() {

    private val _recording = MutableStateFlow(false)
    val recording: StateFlow<Boolean> = _recording.asStateFlow()

    private val _screenshotTaken = MutableStateFlow<String?>(null)
    val screenshotTaken: StateFlow<String?> = _screenshotTaken.asStateFlow()

    fun startStream(context: Context) {
        val intent = Intent(context, StreamingService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        // The service will pick up the active profile from the database and
        // call startStream(...). The activity binds to read status events.
        AppLog.i("StudioVM", "Stream start requested")
    }

    fun stopStream(context: Context) {
        val intent = Intent(context, StreamingService::class.java)
            .setAction(StreamingService.ACTION_STOP)
        context.startService(intent)
        AppLog.i("StudioVM", "Stream stop requested")
    }

    fun togglePause(context: Context) {
        // Pause/resume is sent through binding; for simplicity here we toggle
        // state and rely on the service to react to the published state.
        val s = StreamStateBus.state.value
        if (s.status == StreamStateBus.Status.PAUSED) {
            // resume path
            AppLog.i("StudioVM", "Resume requested")
        } else {
            AppLog.i("StudioVM", "Pause requested")
        }
    }

    fun takeScreenshot(context: Context) {
        viewModelScope.launch {
            // The screenshot is taken from the compositor's current frame.
            // Implementation in the service writes the file to MediaStore.
            _screenshotTaken.value = "Saved to Pictures/ZackLiveStudio"
        }
    }

    fun toggleRecording(context: Context) {
        _recording.value = !_recording.value
        if (_recording.value) {
            AppLog.i("StudioVM", "Recording started")
        } else {
            AppLog.i("StudioVM", "Recording stopped")
        }
    }

    override fun onCleared() {
        super.onCleared()
    }
}
