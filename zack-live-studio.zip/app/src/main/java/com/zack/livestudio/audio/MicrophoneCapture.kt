package com.zack.livestudio.audio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.zack.livestudio.streaming.StreamConfig
import com.zack.livestudio.util.AppLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Microphone capture thread. Reads 16-bit PCM frames at the configured
 * sample rate and channels, computes an RMS-based level meter, and feeds
 * the data into a callback that pushes it downstream into the audio encoder.
 *
 * Internal/system audio capture (PlaybackCapture) is conditional on
 * Android 10+ and requires the app to be flagged as an accessibility or
 * media-projection source. When the system does not permit it, the
 * [InternalAudioCapture] reports a clean error state and the user is
 * informed through the UI — never silently fails.
 */
class MicrophoneCapture(
    private val config: StreamConfig,
    private val onSamples: (ByteArray, Long) -> Unit
) {
    private var record: AudioRecord? = null
    private var thread: Thread? = null
    private val running = AtomicBoolean(false)

    private val _levelDb = MutableStateFlow(-100f)
    val levelDb: StateFlow<Float> = _levelDb

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    private var gainFactor = 1f

    fun prepare(): Boolean {
        val minBuf = AudioRecord.getMinBufferSize(
            config.audioSampleRateHz,
            if (config.audioChannelCount == 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = (minBuf * 2).coerceAtLeast(8192)
        try {
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                config.audioSampleRateHz,
                if (config.audioChannelCount == 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                AppLog.e(TAG, "AudioRecord not initialized")
                return false
            }
            record = r
            return true
        } catch (e: SecurityException) {
            AppLog.e(TAG, "Mic permission denied: ${e.message}")
            return false
        } catch (e: Exception) {
            AppLog.e(TAG, "AudioRecord exception: ${e.message}")
            return false
        }
    }

    fun start() {
        val r = record ?: run {
            if (!prepare()) return
            record ?: return
        }
        if (running.getAndSet(true)) return
        r.startRecording()
        thread = Thread({ loop(r) }, "MicCapture-Loop").apply { start() }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null
        thread?.join(300)
        thread = null
        _levelDb.value = -100f
    }

    fun setMuted(muted: Boolean) { _isMuted.value = muted }
    fun setGain(gainDb: Float) {
        // gain in dB, convert to linear multiplier clamped to 0..4
        gainFactor = (Math.pow(10.0, (gainDb / 20.0).toDouble())).toFloat().coerceIn(0f, 4f)
    }

    private fun loop(r: AudioRecord) {
        val chunk = 1024
        val buf = ShortArray(chunk)
        while (running.get()) {
            val n = try { r.read(buf, 0, chunk) } catch (e: Exception) {
                AppLog.w(TAG, "AudioRecord.read failed: ${e.message}")
                break
            }
            if (n <= 0) continue
            // Compute RMS for level meter
            var sum = 0.0
            for (i in 0 until n) {
                val v = buf[i].toInt()
                sum += (v * v).toDouble()
            }
            val rms = Math.sqrt(sum / n).toFloat().coerceAtLeast(1f)
            val db = (20f * Math.log10(rms / 32767.0)).toFloat()
            _levelDb.value = db

            val bytes = ByteArray(n * 2)
            if (_isMuted.value) {
                java.util.Arrays.fill(bytes, 0)
            } else {
                ByteBuffer.wrap(bytes).asShortBuffer().apply {
                    for (i in 0 until n) {
                        val scaled = (buf[i] * gainFactor).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        put(scaled.toShort())
                    }
                }
            }
            val ptsUs = System.nanoTime() / 1000
            onSamples(bytes, ptsUs)
        }
    }

    companion object { private const val TAG = "MicrophoneCapture" }
}
