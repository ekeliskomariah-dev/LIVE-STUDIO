package com.zack.livestudio.streaming

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.zack.livestudio.util.AppLog
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Writes stream recordings to the public Movies directory via MediaStore,
 * so they appear in the user's gallery and survive app uninstall.
 *
 * On API <  Q we use legacy external storage path under
 * Environment.getExternalStorageDirectory()/Movies/ZackLiveStudio.
 */
class RecordingHelper(private val context: Context) {

    private var currentOutputStream: OutputStream? = null
    private var currentFileUri: Uri? = null
    private var currentFile: File? = null
    private var startedAt: Long = 0L
    private var bytesWritten: Long = 0L

    @Synchronized
    fun startRecording(resolutionLabel: String, container: String = "mp4"): Uri? {
        if (currentOutputStream != null) {
            AppLog.w(TAG, "Already recording")
            return currentFileUri
        }
        val ts = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val name = "Zack_${ts}_$resolutionLabel.$container"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/$container")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZackLiveStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val uri = resolver.insert(collection, values) ?: return null
            currentOutputStream = resolver.openOutputStream(uri)
            currentFileUri = uri
            startedAt = System.currentTimeMillis()
            bytesWritten = 0L
            uri
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "ZackLiveStudio").apply { mkdirs() }
            val f = File(dir, name)
            currentOutputStream = f.outputStream()
            currentFile = f
            startedAt = System.currentTimeMillis()
            bytesWritten = 0L
            Uri.fromFile(f)
        }
    }

    @Synchronized
    fun write(data: ByteArray) {
        val out = currentOutputStream ?: return
        try {
            out.write(data)
            out.flush()
            bytesWritten += data.size
        } catch (e: Exception) {
            AppLog.w(TAG, "Recording write error: ${e.message}")
        }
    }

    @Synchronized
    fun stopRecording(): Long {
        val out = currentOutputStream ?: return 0L
        try { out.flush(); out.close() } catch (_: Exception) {}
        currentOutputStream = null

        // Mark MediaStore entry as no longer pending (Q+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && currentFileUri != null) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.IS_PENDING, 0)
            }
            context.contentResolver.update(currentFileUri!!, values, null, null)
        }
        val duration = System.currentTimeMillis() - startedAt
        currentFileUri = null
        currentFile = null
        startedAt = 0L
        return duration
    }

    fun isRecording(): Boolean = currentOutputStream != null

    companion object { private const val TAG = "RecordingHelper" }
}
