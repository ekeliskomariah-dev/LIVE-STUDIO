package com.zack.livestudio.streaming

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.zack.livestudio.util.AppLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Saves a screenshot bitmap (captured from the compositor) to the public
 * Pictures directory via MediaStore.
 */
class ScreenshotHelper(private val context: Context) {

    @Synchronized
    fun save(bitmap: Bitmap): Uri? {
        val ts = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val name = "Zack_$ts.png"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZackLiveStudio")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            ) ?: return null
            context.contentResolver.openOutputStream(uri)?.use { os ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, os)
            } ?: return null
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            uri
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "ZackLiveStudio").apply { mkdirs() }
            val f = File(dir, name)
            try {
                f.outputStream().use { os -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, os) }
                Uri.fromFile(f)
            } catch (e: Exception) {
                AppLog.e(TAG, "Screenshot save failed: ${e.message}")
                null
            }
        }
    }

    companion object { private const val TAG = "ScreenshotHelper" }
}
