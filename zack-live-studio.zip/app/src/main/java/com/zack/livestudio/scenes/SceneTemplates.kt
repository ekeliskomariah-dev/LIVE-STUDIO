package com.zack.livestudio.scenes

import com.zack.livestudio.overlay.LayerModel
import com.zack.livestudio.overlay.LayerPayload
import com.zack.livestudio.overlay.LayerTransform
import com.zack.livestudio.overlay.LayerType
import com.zack.livestudio.overlay.Scene
import java.util.UUID

/**
 * Factory for the five scene templates mentioned in the spec. Each template
 * provides a sensible starting layout that the user can immediately start
 * customizing. The templates intentionally start empty (no real source URL
 * assigned) so they don't reference fake data.
 */
object SceneTemplates {

    fun blank(name: String = "New Scene"): Scene {
        val now = System.currentTimeMillis()
        return Scene(
            id = UUID.randomUUID().toString(),
            name = name,
            layers = listOf(
                LayerModel(
                    id = "bg-${UUID.randomUUID()}",
                    type = LayerType.BACKGROUND,
                    name = "Background",
                    transform = LayerTransform(
                        x = 0f, y = 0f, width = 1f, height = 1f,
                        opacity = 1f, visible = true
                    ),
                    payload = LayerPayload.Background(color = "#FF0D0F1F"),
                    zOrder = 0
                )
            ),
            createdAt = now,
            updatedAt = now
        )
    }

    fun gaming(): Scene = blank("Gaming").let { s ->
        s.copy(
            layers = s.layers + listOf(
                LayerModel(
                    id = "screen-${UUID.randomUUID()}",
                    type = LayerType.SCREEN,
                    name = "Screen/Game",
                    transform = LayerTransform(width = 1f, height = 1f),
                    payload = LayerPayload.Screen(),
                    zOrder = 10
                ),
                LayerModel(
                    id = "cam-${UUID.randomUUID()}",
                    type = LayerType.CAMERA,
                    name = "Camera",
                    transform = LayerTransform(
                        x = 0.74f, y = 0.04f, width = 0.22f, height = 0.22f
                    ),
                    payload = LayerPayload.Camera(lensFacingFront = true, mirror = true),
                    zOrder = 20
                )
            )
        )
    }

    fun justChatting(): Scene = blank("Just Chatting").let { s ->
        s.copy(
            layers = s.layers + listOf(
                LayerModel(
                    id = "cam-${UUID.randomUUID()}",
                    type = LayerType.CAMERA,
                    name = "Camera",
                    transform = LayerTransform(width = 1f, height = 1f),
                    payload = LayerPayload.Camera(lensFacingFront = true, mirror = false),
                    zOrder = 10
                ),
                LayerModel(
                    id = "title-${UUID.randomUUID()}",
                    type = LayerType.TEXT,
                    name = "Title",
                    transform = LayerTransform(x = 0.05f, y = 0.82f, width = 0.6f, height = 0.12f),
                    payload = LayerPayload.Text(content = "Live with Zack Live Studio", fontSizeSp = 28, bold = true),
                    zOrder = 20
                )
            )
        )
    }

    fun startingSoon(): Scene = blank("Starting Soon").let { s ->
        s.copy(
            layers = s.layers + listOf(
                LayerModel(
                    id = "title-${UUID.randomUUID()}",
                    type = LayerType.TEXT,
                    name = "Title",
                    transform = LayerTransform(x = 0.1f, y = 0.42f, width = 0.8f, height = 0.16f),
                    payload = LayerPayload.Text(content = "Starting Soon", fontSizeSp = 64, bold = true, align = "center"),
                    zOrder = 10
                )
            )
        )
    }

    fun brb(): Scene = blank("BRB").let { s ->
        s.copy(
            layers = s.layers + listOf(
                LayerModel(
                    id = "title-${UUID.randomUUID()}",
                    type = LayerType.TEXT,
                    name = "Title",
                    transform = LayerTransform(x = 0.1f, y = 0.42f, width = 0.8f, height = 0.16f),
                    payload = LayerPayload.Text(content = "Be Right Back", fontSizeSp = 64, bold = true, align = "center"),
                    zOrder = 10
                )
            )
        )
    }

    fun ending(): Scene = blank("Ending").let { s ->
        s.copy(
            layers = s.layers + listOf(
                LayerModel(
                    id = "title-${UUID.randomUUID()}",
                    type = LayerType.TEXT,
                    name = "Title",
                    transform = LayerTransform(x = 0.1f, y = 0.42f, width = 0.8f, height = 0.16f),
                    payload = LayerPayload.Text(content = "Thanks for watching!", fontSizeSp = 56, bold = true, align = "center"),
                    zOrder = 10
                )
            )
        )
    }

    fun fromTemplate(name: String): Scene = when (name) {
        "Gaming" -> gaming()
        "Just Chatting" -> justChatting()
        "Starting Soon" -> startingSoon()
        "BRB" -> brb()
        "Ending" -> ending()
        else -> blank(name)
    }
}
