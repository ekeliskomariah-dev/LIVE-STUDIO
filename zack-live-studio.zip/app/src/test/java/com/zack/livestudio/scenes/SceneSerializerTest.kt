package com.zack.livestudio.scenes

import com.zack.livestudio.overlay.LayerModel
import com.zack.livestudio.overlay.LayerPayload
import com.zack.livestudio.overlay.LayerTransform
import com.zack.livestudio.overlay.LayerType
import com.zack.livestudio.overlay.Scene
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class SceneSerializerTest {

    @Test fun serialize_deserialize_round_trip_preserves_layers() {
        val original = Scene(
            id = "s-1",
            name = "Gaming",
            layers = listOf(
                LayerModel(
                    id = "bg", type = LayerType.BACKGROUND, name = "Background",
                    transform = LayerTransform(),
                    payload = LayerPayload.Background(color = "#FF0D0F1F"),
                    zOrder = 0
                ),
                LayerModel(
                    id = "screen", type = LayerType.SCREEN, name = "Screen",
                    transform = LayerTransform(width = 1f, height = 1f),
                    payload = LayerPayload.Screen(captureWidth = 1920, captureHeight = 1080),
                    zOrder = 10
                ),
                LayerModel(
                    id = "cam", type = LayerType.CAMERA, name = "Camera",
                    transform = LayerTransform(x = 0.74f, y = 0.04f, width = 0.22f, height = 0.22f),
                    payload = LayerPayload.Camera(lensFacingFront = true, mirror = true),
                    zOrder = 20
                ),
                LayerModel(
                    id = "url1", type = LayerType.BROWSER, name = "Donation",
                    transform = LayerTransform(x = 0.05f, y = 0.05f, width = 0.3f, height = 0.3f),
                    payload = LayerPayload.Browser(url = "https://sociabuzz.com/zack"),
                    zOrder = 30
                ),
                LayerModel(
                    id = "title", type = LayerType.TEXT, name = "Title",
                    transform = LayerTransform(x = 0.1f, y = 0.82f),
                    payload = LayerPayload.Text(
                        content = "Hello world",
                        fontSizeSp = 32,
                        bold = true,
                        color = "#FFFFFFFF"
                    ),
                    zOrder = 40
                )
            ),
            createdAt = 123456789L,
            updatedAt = 987654321L
        )
        val json = SceneSerializer.serialize(original)
        val restored = SceneSerializer.deserialize(json)
        assertNotNull(restored)
        assertEquals(original.id, restored!!.id)
        assertEquals(original.name, restored.name)
        assertEquals(original.layers.size, restored.layers.size)
        assertEquals(original.createdAt, restored.createdAt)
        assertEquals(original.updatedAt, restored.updatedAt)
        assertEquals(original.layers.map { it.id }, restored.layers.map { it.id })
    }

    @Test fun deserialize_garbage_returns_null() {
        assertNull(SceneSerializer.deserialize("not json"))
        assertNull(SceneSerializer.deserialize("{\"foo\":\"bar\"}"))
    }

    @Test fun deserialize_empty_string_returns_null() {
        assertNull(SceneSerializer.deserialize(""))
    }
}
