package com.zack.livestudio.util

import android.net.Uri
import android.webkit.URLUtil
import java.net.URI
import java.net.URL
import java.util.Locale

/**
 * Validation utilities for URLs used by browser sources and stream profiles.
 * NEVER accept URLs that could be used for file-system or javascript injection.
 */
object UrlValidator {

    private val ALLOWED_SCHEMES = setOf("http", "https")

    /**
     * Returns true when the input is a syntactically valid http/https URL
     * pointing at a real network host. NEVER returns true for javascript:,
     * file:, content:, etc.
     */
    fun isHttpUrl(input: String?): Boolean {
        if (input.isNullOrBlank()) return false
        val trimmed = input.trim()
        if (trimmed.length > 2048) return false
        return try {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase(Locale.US) ?: return false
            if (scheme !in ALLOWED_SCHEMES) return false
            val host = uri.host ?: return false
            if (host.isEmpty()) return false
            // basic sanity check on host (no spaces, has a dot or is localhost)
            if (' ' in host) return false
            host.contains('.') || host == "localhost"
        } catch (_: Exception) {
            false
        }
    }

    fun sanitize(input: String): String {
        return input.trim()
            .replace("\n", "")
            .replace("\r", "")
    }

    /**
     * Normalize an input the user typed without a scheme so we can attempt
     * to load it as https://. Returns null when the input is unusable.
     */
    fun normalize(input: String?): String? {
        if (input.isNullOrBlank()) return null
        val s = sanitize(input)
        if (isHttpUrl(s)) return s
        if (isHttpUrl("https://$s")) return "https://$s"
        return null
    }

    fun isValidRtmpUrl(input: String?): Boolean {
        if (input.isNullOrBlank()) return false
        return try {
            val uri = URI(input.trim())
            val scheme = uri.scheme?.lowercase(Locale.US) ?: return false
            if (scheme != "rtmp" && scheme != "rtmps") return false
            val host = uri.host ?: return false
            host.isNotEmpty() && !host.contains(' ')
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Stream keys are arbitrary tokens supplied by the user. We only
     * validate that they are non-empty, no whitespace, reasonable length.
     */
    fun isValidStreamKey(input: String?): Boolean {
        if (input.isNullOrBlank()) return false
        if (input.length < 4 || input.length > 256) return false
        return input.none { it.isWhitespace() }
    }
}
