package com.zack.livestudio.streaming

import org.junit.Assert.assertEquals
import org.junit.Test

class StreamConfigTest {

    @Test fun low_preset_yields_720p_30fps_2mbps() {
        val cfg = StreamConfig.fromPreset(StreamConfig.Preset.LOW,
            StreamConfig.PerformanceMode.BALANCED)
        assertEquals(StreamConfig.RES_720P_W, cfg.videoWidth)
        assertEquals(StreamConfig.RES_720P_H, cfg.videoHeight)
        assertEquals(30, cfg.fps)
        assertEquals(2000, cfg.videoBitrateKbps)
        assertEquals(96, cfg.audioBitrateKbps)
        assertEquals(StreamConfig.Preset.LOW, cfg.preset)
    }

    @Test fun balanced_preset_yields_720p_30fps_4_5mbps() {
        val cfg = StreamConfig.fromPreset(StreamConfig.Preset.BALANCED,
            StreamConfig.PerformanceMode.BALANCED)
        assertEquals(StreamConfig.RES_720P_W, cfg.videoWidth)
        assertEquals(4500, cfg.videoBitrateKbps)
        assertEquals(128, cfg.audioBitrateKbps)
    }

    @Test fun high_preset_yields_1080p_60fps_8mbps() {
        val cfg = StreamConfig.fromPreset(StreamConfig.Preset.HIGH,
            StreamConfig.PerformanceMode.BALANCED)
        assertEquals(StreamConfig.RES_1080P_W, cfg.videoWidth)
        assertEquals(StreamConfig.RES_1080P_H, cfg.videoHeight)
        assertEquals(60, cfg.fps)
        assertEquals(8000, cfg.videoBitrateKbps)
    }

    @Test fun custom_preset_uses_defaults() {
        val cfg = StreamConfig.fromPreset(StreamConfig.Preset.CUSTOM,
            StreamConfig.PerformanceMode.PERFORMANCE)
        assertEquals(StreamConfig.Preset.CUSTOM, cfg.preset)
        assertEquals(StreamConfig.PerformanceMode.PERFORMANCE, cfg.performanceMode)
    }
}
