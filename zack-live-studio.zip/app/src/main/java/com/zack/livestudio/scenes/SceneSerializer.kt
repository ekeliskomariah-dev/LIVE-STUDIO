package com.zack.livestudio.scenes

import com.zack.livestudio.overlay.Scene
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.jsonObject

/**
 * Serializes/deserializes a [Scene] to/from JSON for persistent storage.
 *
 * The schema version is embedded so future migrations can detect and
 * upgrade older saved scenes. LayerPayload is a sealed class so
 * kotlinx.serialization handles polymorphism via the class discriminator
 * field `"type"`.
 */
object SceneSerializer {

    const val SCHEMA_VERSION = 1

    val json: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = false
        classDiscriminator = "type"
    }

    fun serialize(scene: Scene): String {
        val payload = buildJsonObject {
            put("schemaVersion", SCHEMA_VERSION)
            put("scene", json.encodeToJsonElement(Scene.serializer(), scene))
        }
        return json.encodeToString(JsonObject.serializer(), payload)
    }

    fun deserialize(jsonStr: String): Scene? {
        return try {
            val element = json.parseToJsonElement(jsonStr)
            val obj = element.jsonObject
            val sceneElement = obj["scene"] ?: return null
            json.decodeFromJsonElement(Scene.serializer(), sceneElement)
        } catch (_: Exception) { null }
    }
}

class SceneRepository(private val dao: com.zack.livestudio.storage.dao.SceneDao) {
    suspend fun save(scene: Scene) {
        dao.upsert(
            com.zack.livestudio.storage.entity.SceneEntity(
                id = scene.id,
                name = scene.name,
                json = SceneSerializer.serialize(scene),
                createdAt = scene.createdAt,
                updatedAt = scene.updatedAt
            )
        )
    }

    suspend fun load(id: String): Scene? {
        val entity = dao.findById(id) ?: return null
        return SceneSerializer.deserialize(entity.json)
    }

    suspend fun delete(id: String) = dao.deleteById(id)

    fun observeAll() = dao.observeAll()
}
