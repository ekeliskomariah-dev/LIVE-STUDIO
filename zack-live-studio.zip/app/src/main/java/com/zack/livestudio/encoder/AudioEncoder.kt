package com.zack.livestudio.encoder

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import com.zack.livestudio.streaming.StreamConfig
import com.zack.livestudio.util.AppLog
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * AAC LC audio encoder. Takes raw PCM (16-bit, stereo @ sample rate from
 * config) from [feed] and emits AAC frames via [onOutput] callback.
 *
 * Sample rate / channel count come from [StreamConfig]. The audio is read
 * from a circular buffer maintained by the audio mixer so we don't have to
 * deal with AudioRecord directly here.
 */
class AudioEncoder(
    private val config: StreamConfig,
    private val onOutput: (Sample) -> Unit
) {
    private var codec: MediaCodec? = null
    private val running = AtomicBoolean(false)
    private var thread: Thread? = null
    private val pendingInput = ArrayDeque<ByteArray>()
    private val lock = Any()
    @Volatile private var firstPtsUs = -1L
    @Volatile private var totalInputBytes = 0L

    fun prepare() {
        if (codec != null) return
        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_AAC,
            config.audioSampleRateHz,
            config.audioChannelCount
        ).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, config.audioBitrateKbps * 1000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 8192)
        }
        val codecName = MediaCodecListProvider.bestAacEncoderName() ?: "OMX.google.aac.encoder"
        AppLog.i(TAG, "Creating audio codec: $codecName")
        val c = MediaCodec.createByCodecName(codecName)
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec = c
    }

    fun start() {
        if (running.getAndSet(true)) return
        prepare()
        codec?.start()
        thread = Thread({ drainLoop() }, "AudioEncoder-Loop").apply { start() }
    }

    fun feed(pcm: ByteArray, ptsUs: Long) {
        synchronized(lock) {
            // We keep at most ~100ms of buffered audio to avoid latency bloat
            while (pendingInput.size > 64 && pendingInput.first().size <= totalInputBytes) {
                val popped = pendingInput.removeFirst()
                totalInputBytes -= popped.size
            }
            pendingInput.addLast(pcm)
            (pendingInput as java.util.ArrayDeque<ByteArray>)
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        codec = null
        thread?.join(300)
        thread = null
        synchronized(lock) { pendingInput.clear() }
        firstPtsUs = -1L
        totalInputBytes = 0L
    }

    private fun drainLoop() {
        val c = codec ?: return
        val bufferInfo = MediaCodec.BufferInfo()
        while (running.get()) {
            try {
                // 1) Feed input
                var queuedThisLoop = 0
                while (queuedThisLoop < 4) {
                    val inIndex = c.dequeueInputBuffer(2_000L)
                    if (inIndex < 0) break
                    val inBuf: ByteBuffer = c.getInputBuffer(inIndex) ?: break
                    val pcm = synchronized(lock) {
                        if (pendingInput.isEmpty()) null else pendingInput.removeFirst()
                    } ?: break
                    inBuf.clear()
                    val n = minOf(pcm.size, inBuf.capacity())
                    inBuf.put(pcm, 0, n)
                    val ptsUs = System.nanoTime() / 1000
                    c.queueInputBuffer(inIndex, 0, n, ptsUs, 0)
                    queuedThisLoop++
                }

                // 2) Drain output
                while (true) {
                    val outIndex = c.dequeueOutputBuffer(bufferInfo, 0L)
                    if (outIndex >= 0) {
                        val out: ByteBuffer = c.getOutputBuffer(outIndex) ?: break
                        if (bufferInfo.size > 0) {
                            val copy = ByteArray(bufferInfo.size)
                            out.position(bufferInfo.offset)
                            out.get(copy, 0, bufferInfo.size)
                            if (firstPtsUs < 0) firstPtsUs = bufferInfo.presentationTimeUs
                            val ptsMs = (bufferInfo.presentationTimeUs - firstPtsUs) / 1000
                            onOutput(
                                Sample(
                                    data = copy,
                                    ptsMs = ptsMs.coerceAtLeast(0).toInt(),
                                    isConfig = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                                )
                            )
                        }
                        c.releaseOutputBuffer(outIndex, false)
                    } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        AppLog.i(TAG, "AAC output format changed: ${c.outputFormat}")
                    }
                }
                if (queuedThisLoop == 0) Thread.sleep(2)
            } catch (e: Exception) {
                if (running.get()) AppLog.w(TAG, "audio drain error: ${e.message}")
                else break
            }
        }
    }

    data class Sample(
        val data: ByteArray,
        val ptsMs: Int,
        val isConfig: Boolean
    )

    companion object { private const val TAG = "AudioEncoder" }
}
