package com.zack.livestudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.zack.livestudio.R
import com.zack.livestudio.chat.ChatMessage
import com.zack.livestudio.ui.components.EmptyState
import com.zack.livestudio.ui.components.GlassPanel
import com.zack.livestudio.ui.theme.NeonBlue
import com.zack.livestudio.ui.theme.NeonPurple

@Composable
fun ChatScreen(navController: NavController, vm: ChatViewModel = viewModel()) {
    val messages by vm.messages.collectAsState(emptyList())
    val connected by vm.connected.collectAsState(false)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.nav_chat), fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(MaterialTheme.colorScheme.background)
        ) {
            if (messages.isEmpty()) {
                EmptyState(
                    title = "No chat provider connected",
                    hint = "Add a WebSocket or REST chat endpoint in Settings to see live chat here."
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatRow(msg)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatRow(msg: ChatMessage) {
    GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(8.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Text("${msg.username}: ",
                color = msg.color?.let { parseColorHex(it) } ?: NeonBlue,
                fontWeight = FontWeight.SemiBold
            )
            Text(msg.text, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

private fun parseColorHex(hex: String): androidx.compose.ui.graphics.Color {
    return try {
        val v = if (hex.startsWith("#")) hex.substring(1) else hex
        val r = v.substring(0, 2).toInt(16)
        val g = v.substring(2, 4).toInt(16)
        val b = v.substring(4, 6).toInt(16)
        androidx.compose.ui.graphics.Color(r, g, b)
    } catch (_: Exception) { NeonBlue }
}
