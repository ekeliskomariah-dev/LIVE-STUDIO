package com.zack.livestudio.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zack.livestudio.R
import com.zack.livestudio.ui.theme.NeonBlue
import com.zack.livestudio.ui.theme.NeonCyan
import com.zack.livestudio.ui.theme.NeonPurple
import kotlinx.coroutines.delay

@Composable
fun LoadingScreen(onComplete: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    var stage by remember { mutableStateOf("") }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = stringResource(R.string.app_name),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = stringResource(R.string.app_tagline),
                fontSize = 14.sp,
                color = NeonCyan
            )
            Spacer(Modifier.height(32.dp))
            Text(
                text = stringResource(R.string.loading_engine),
                color = Color.White.copy(alpha = 0.8f)
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .width(220.dp)
                    .height(6.dp),
                color = NeonBlue,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text(stage, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
    }

    LaunchedEffect(Unit) {
        val stages = listOf(
            R.string.loading_renderer,
            R.string.loading_camera,
            R.string.loading_audio,
            R.string.loading_browser,
            R.string.loading_encoder,
            R.string.loading_ready
        )
        for ((i, s) in stages.withIndex()) {
            stage = stringResource(s)
            val target = (i + 1) / stages.size.toFloat()
            while (progress < target) {
                progress = (progress + 0.05f).coerceAtMost(target)
                delay(30)
            }
        }
        delay(200)
        onComplete()
    }
}
