package com.zack.livestudio.util

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Tracks the current state of the streaming service as a StateFlow so the UI
 * can observe it without coupling to the service directly.
 */
object StreamStateBus {

    enum class Status {
        IDLE, CONNECTING, LIVE, PAUSED, RECONNECTING, ERROR, ENDED
    }

    data class StreamState(
        val status: Status = Status.IDLE,
        val durationSec: Long = 0L,
        val fps: Float = 0f,
        val bitrateKbps: Int = 0,
        val droppedFrames: Int = 0,
        val reconnectCount: Int = 0,
        val networkType: String = "Unknown",
        val cpuPercent: Int = 0,
        val ramPercent: Int = 0,
        val temperatureC: Float = -1f,
        val audioLevelDb: Float = -100f,
        val errorMessage: String? = null,
        val safeModeReason: String? = null
    )

    private val _state = MutableStateFlow(StreamState())
    val state: StateFlow<StreamState> = _state

    fun update(transform: (StreamState) -> StreamState) {
        _state.value = transform(_state.value)
    }

    fun reset() { _state.value = StreamState() }
}
