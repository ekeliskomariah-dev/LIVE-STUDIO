package com.zack.livestudio.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.StatFs
import java.io.RandomAccessFile

/**
 * Read-only accessors for system performance metrics used by the
 * streaming statistics UI. None of these methods are blocking beyond
 * a few milliseconds.
 */
object SystemInfo {

    fun totalRamMb(context: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.totalMem / (1024 * 1024)
    }

    fun availableRamMb(context: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem / (1024 * 1024)
    }

    fun usedRamMb(context: Context): Long = totalRamMb(context) - availableRamMb(context)

    fun ramUsagePercent(context: Context): Int {
        val total = totalRamMb(context).coerceAtLeast(1)
        return ((usedRamMb(context).toFloat() / total) * 100f).toInt().coerceIn(0, 100)
    }

    /**
     * CPU usage % since last call. Sampled from /proc/stat.
     * Returns -1 if unavailable.
     */
    private var lastCpu: LongArray? = null

    @Synchronized
    fun cpuUsagePercent(): Int {
        return try {
            val rf = RandomAccessFile("/proc/stat", "r")
            val line = rf.readLine() ?: return -1
            rf.close()
            val parts = line.split(Regex("\\s+")).drop(1).map { it.toLong() }
            if (parts.size < 4) return -1
            val idle = parts[3]
            val total = parts.sum()
            val prev = lastCpu
            lastCpu = parts.toLongArray()
            if (prev == null) return 0
            val prevTotal = prev.sum()
            val prevIdle = prev[3]
            val totalDiff = (total - prevTotal).coerceAtLeast(1)
            val idleDiff = idle - prevIdle
            (((totalDiff - idleDiff) * 100) / totalDiff).toInt().coerceIn(0, 100)
        } catch (_: Exception) {
            -1
        }
    }

    /**
     * Returns battery/thermal temperature in degrees Celsius, or -1f when not available.
     */
    fun batteryTemperatureC(context: Context): Float {
        return try {
            val intent = context.registerReceiver(null,
                android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            if (intent != null) {
                val temp = intent.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, -1)
                if (temp > 0) temp / 10f else -1f
            } else -1f
        } catch (_: Exception) { -1f }
    }

    fun isThermalThrottled(context: Context): Boolean {
        return batteryTemperatureC(context) >= 42f
    }
}
