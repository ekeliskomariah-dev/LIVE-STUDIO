package com.zack.livestudio.streaming.rtmp

import com.zack.livestudio.util.AppLog
import java.io.IOException
import java.net.URI

/**
 * Parses an RTMP URL into host, port, app, and stream key portions.
 *
 * Format: rtmp://host[:port]/app[/streamKey]
 *
 * Examples:
 *   rtmp://a.rtmp.youtube.com/live2/abcd-1234-efgh
 *   rtmp://live.twitch.tv/app/live_123456789_abc
 *   rtmp://custom.example.com:1935/live/stream1
 */
object RtmpUrl {

    data class Parsed(
        val host: String,
        val port: Int,
        val app: String,
        val streamKey: String?,
        val raw: String
    )

    fun parse(input: String): Parsed? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null
        return try {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase() ?: return null
            if (scheme != "rtmp" && scheme != "rtmps") return null
            val host = uri.host ?: return null
            if (host.isEmpty()) return null
            val port = if (uri.port == -1) 1935 else uri.port
            val path = uri.path?.trimStart('/') ?: ""
            if (path.isEmpty()) return Parsed(host, port, "live", null, trimmed)
            val parts = path.split('/', limit = 2)
            val app = parts[0]
            val streamKey = parts.getOrNull(1)?.ifEmpty { null }
            Parsed(host, port, app, streamKey, trimmed)
        } catch (e: Exception) {
            AppLog.w("RtmpUrl", "Failed to parse '$input': ${e.message}")
            null
        }
    }

    fun isValid(input: String): Boolean = parse(input) != null

    @Throws(IOException::class)
    fun requireValid(input: String): Parsed {
        return parse(input) ?: throw IOException("Invalid RTMP URL: $input")
    }
}
