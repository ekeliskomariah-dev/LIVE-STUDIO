package com.zack.livestudio.ui

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Thin wrapper around NotificationManagerCompat so service code can post
 * stream status updates without depending on NotificationManager plumbing
 * directly.
 */
object NotificationHelper {
    fun notify(context: Context, id: Int, notification: Notification) {
        try {
            val mgr = NotificationManagerCompat.from(context)
            if (mgr.areNotificationsEnabled()) {
                mgr.notify(id, notification)
            }
        } catch (_: SecurityException) {
            // Notification permission may not be granted yet — fail silently
        } catch (_: Exception) { }
    }

    fun cancel(context: Context, id: Int) {
        try {
            NotificationManagerCompat.from(context).cancel(id)
        } catch (_: Exception) { }
    }
}
