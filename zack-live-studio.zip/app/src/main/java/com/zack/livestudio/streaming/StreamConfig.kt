package com.zack.livestudio.streaming

/**
 * Output configuration for the stream engine. These values are derived from
 * the user-selected preset and then applied to MediaCodec / AAC encoders.
 */
data class StreamConfig(
    val videoWidth: Int = 1280,
    val videoHeight: Int = 720,
    val fps: Int = 30,
    val videoBitrateKbps: Int = 4500,
    val audioSampleRateHz: Int = 44_100,
    val audioChannelCount: Int = 2,
    val audioBitrateKbps: Int = 128,
    val keyframeIntervalSec: Int = 2,
    val useHardwareEncoder: Boolean = true,
    val profileLevel: Int = 0,
    val preset: Preset = Preset.BALANCED,
    val performanceMode: PerformanceMode = PerformanceMode.BALANCED
) {
    enum class Preset { LOW, BALANCED, HIGH, CUSTOM }
    enum class PerformanceMode { BATTERY_SAVER, BALANCED, PERFORMANCE }

    companion object {
        const val RES_480P_W = 854
        const val RES_480P_H = 480
        const val RES_720P_W = 1280
        const val RES_720P_H = 720
        const val RES_1080P_W = 1920
        const val RES_1080P_H = 1080

        fun fromPreset(preset: Preset, perf: PerformanceMode, perfMode: PerformanceMode = perf): StreamConfig {
            return when (preset) {
                Preset.LOW -> StreamConfig(
                    videoWidth = RES_720P_W, videoHeight = RES_720P_H, fps = 30,
                    videoBitrateKbps = 2000, audioBitrateKbps = 96,
                    preset = preset, performanceMode = perfMode
                )
                Preset.BALANCED -> StreamConfig(
                    videoWidth = RES_720P_W, videoHeight = RES_720P_H, fps = 30,
                    videoBitrateKbps = 4500, audioBitrateKbps = 128,
                    preset = preset, performanceMode = perfMode
                )
                Preset.HIGH -> StreamConfig(
                    videoWidth = RES_1080P_W, videoHeight = RES_1080P_H, fps = 60,
                    videoBitrateKbps = 8000, audioBitrateKbps = 160,
                    preset = preset, performanceMode = perfMode
                )
                Preset.CUSTOM -> StreamConfig(
                    preset = preset, performanceMode = perfMode
                )
            }
        }
    }
}
