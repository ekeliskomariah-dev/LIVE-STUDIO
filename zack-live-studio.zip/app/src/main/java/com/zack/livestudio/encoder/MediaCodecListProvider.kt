package com.zack.livestudio.encoder

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build

/**
 * Thin wrapper around [MediaCodecList] that we can mock in unit tests.
 * Provides lookup helpers for H.264/AAC encoder selection.
 */
object MediaCodecListProvider {

    fun codecInfos(): Array<MediaCodecInfo> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        } else {
            // On older API levels we can't query hardware flag; just return all
            @Suppress("DEPRECATION")
            MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos
        }
    }

    fun isHardware(codec: MediaCodecInfo): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            codec.isHardwareAccelerated
        } else {
            // Heuristic: Google encoders are software
            !codec.name.startsWith("OMX.google")
        }
    }

    fun anyAvcEncoder(): String? {
        return codecInfos().firstOrNull { info ->
            info.supportedTypes.any { t -> t.equals(MediaFormat.MIMETYPE_VIDEO_AVC, true) }
        }?.name
    }

    fun bestAacEncoderName(): String? {
        return codecInfos().firstOrNull { info ->
            info.supportedTypes.any { t -> t.equals(MediaFormat.MIMETYPE_AUDIO_AAC, true) }
        }?.name
    }
}
