package com.zack.livestudio.chat

import com.zack.livestudio.util.AppLog
import com.zack.livestudio.util.UrlValidator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Custom WebSocket chat provider. The user supplies a WebSocket URL that
 * emits JSON chat events. This is a real, working implementation: it opens
 * a WebSocket via OkHttp and parses incoming messages using the documented
 * JSON schema (below). It is suitable for connecting to your own chat
 * backend or a relay server.
 *
 * Expected JSON schema from the server (one message per line):
 *   {
 *     "type": "message",
 *     "id":   "<unique id>",
 *     "username": "<author>",
 *     "avatar":  "<url or null>",
 *     "text":    "<message body>",
 *     "ts":      <epoch millis>,
 *     "color":   "#RRGGBB" (optional),
 *     "subscriber": true|false (optional),
 *     "moderator":  true|false (optional)
 *   }
 *
 * Messages with `type` other than "message" are ignored.
 */
class WebSocketChatProvider(
    override val id: String = UUID.randomUUID().toString()
) : ChatProvider {

    override val displayName: String = "Custom WebSocket"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wsJob: Job? = null
    private var socket: WebSocket? = null

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)  // WebSocket stays open
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private val _messages = MutableSharedFlow<ChatMessage>(replay = 0, extraBufferCapacity = 64)
    override val messages: SharedFlow<ChatMessage> = _messages.asSharedFlow()

    private val _state = MutableStateFlow(ChatConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<ChatConnectionState> = _state.asStateFlow()

    override suspend fun connect(config: ChatProviderConfig): Result<Unit> {
        if (!UrlValidator.isHttpUrl(config.endpoint) &&
            !config.endpoint.startsWith("ws://") &&
            !config.endpoint.startsWith("wss://")) {
            _state.value = ChatConnectionState.ERROR
            return Result.failure(IllegalArgumentException("Invalid WebSocket URL"))
        }
        disconnect()
        _state.value = ChatConnectionState.CONNECTING
        val req = Request.Builder()
            .url(config.endpoint)
            .apply {
                config.authToken?.let { header("Authorization", "Bearer $it") }
                config.channelId?.let { header("X-Channel-Id", it) }
            }
            .build()
        wsJob = scope.launch {
            try {
                client.newWebSocket(req, object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        socket = webSocket
                        _state.value = ChatConnectionState.CONNECTED
                        AppLog.i(TAG, "WebSocket connected: ${config.endpoint}")
                    }
                    override fun onMessage(webSocket: WebSocket, text: String) {
                        handleMessage(text)
                    }
                    override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                        handleMessage(bytes.utf8())
                    }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        AppLog.w(TAG, "WebSocket failure: ${t.message}")
                        _state.value = ChatConnectionState.ERROR
                    }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                        _state.value = ChatConnectionState.DISCONNECTED
                        AppLog.i(TAG, "WebSocket closed: $code $reason")
                    }
                })
            } catch (e: Exception) {
                _state.value = ChatConnectionState.ERROR
                AppLog.e(TAG, "WebSocket connect exception: ${e.message}")
            }
        }
        return Result.success(Unit)
    }

    private fun handleMessage(raw: String) {
        try {
            val json = JSONObject(raw)
            if (json.optString("type") != "message") return
            val msg = ChatMessage(
                id = json.optString("id", UUID.randomUUID().toString()),
                provider = displayName,
                username = json.optString("username", "Anonymous"),
                avatarUrl = json.optString("avatar").takeIf { it.isNotBlank() },
                text = json.optString("text", ""),
                timestampMs = if (json.has("ts")) json.getLong("ts") else System.currentTimeMillis(),
                color = json.optString("color").takeIf { it.isNotBlank() },
                isSubscriber = json.optBoolean("subscriber", false),
                isModerator = json.optBoolean("moderator", false)
            )
            scope.launch { _messages.emit(msg) }
        } catch (e: Exception) {
            AppLog.w(TAG, "Bad message payload: ${e.message}")
        }
    }

    override fun sendMessage(text: String): Boolean {
        val s = socket ?: return false
        val payload = JSONObject()
            .put("type", "outgoing")
            .put("text", text)
            .toString()
        return s.send(payload)
    }

    override suspend fun disconnect() {
        wsJob?.cancel()
        try { socket?.close(1000, "Bye") } catch (_: Exception) {}
        socket = null
        _state.value = ChatConnectionState.DISCONNECTED
    }

    companion object { private const val TAG = "WebSocketChatProvider" }
}

/**
 * A REST-polling chat provider. Useful for HTTP-based chat endpoints that
 * expose `GET /messages?since=<ts>`. Polling interval defaults to 2s.
 */
class RestChatProvider(
    override val id: String = UUID.randomUUID().toString(),
    private val pollIntervalMs: Long = 2000L
) : ChatProvider {

    override val displayName: String = "Custom REST"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollJob: Job? = null
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val _messages = MutableSharedFlow<ChatMessage>(replay = 0, extraBufferCapacity = 64)
    override val messages: SharedFlow<ChatMessage> = _messages.asSharedFlow()

    private val _state = MutableStateFlow(ChatConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<ChatConnectionState> = _state.asStateFlow()

    private var lastTs = 0L

    override suspend fun connect(config: ChatProviderConfig): Result<Unit> {
        if (!UrlValidator.isHttpUrl(config.endpoint)) {
            _state.value = ChatConnectionState.ERROR
            return Result.failure(IllegalArgumentException("Invalid REST URL"))
        }
        disconnect()
        _state.value = ChatConnectionState.CONNECTING
        pollJob = scope.launch {
            _state.value = ChatConnectionState.CONNECTED
            while (true) {
                try {
                    val req = Request.Builder()
                        .url("${config.endpoint}?since=$lastTs")
                        .apply {
                            config.authToken?.let { header("Authorization", "Bearer $it") }
                        }
                        .build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val body = resp.body?.string() ?: return@use
                            val arr = org.json.JSONArray(body)
                            for (i in 0 until arr.length()) {
                                val o = arr.optJSONObject(i) ?: continue
                                val ts = o.optLong("ts", 0L)
                                if (ts > lastTs) lastTs = ts
                                val msg = ChatMessage(
                                    id = o.optString("id", UUID.randomUUID().toString()),
                                    provider = displayName,
                                    username = o.optString("username", "Anonymous"),
                                    avatarUrl = o.optString("avatar").takeIf { it.isNotBlank() },
                                    text = o.optString("text", ""),
                                    timestampMs = if (ts > 0) ts else System.currentTimeMillis()
                                )
                                _messages.emit(msg)
                            }
                        } else {
                            AppLog.w(TAG, "REST chat HTTP ${resp.code}")
                        }
                    }
                } catch (e: Exception) {
                    AppLog.w(TAG, "REST poll error: ${e.message}")
                }
                kotlinx.coroutines.delay(pollIntervalMs)
            }
        }
        return Result.success(Unit)
    }

    override suspend fun disconnect() {
        pollJob?.cancel()
        _state.value = ChatConnectionState.DISCONNECTED
    }

    override fun sendMessage(text: String): Boolean = false

    companion object { private const val TAG = "RestChatProvider" }
}

/**
 * Built-in null provider. Used when the user has not configured a chat
 * integration yet — surfaces an empty list rather than a fake one.
 */
class NullChatProvider : ChatProvider {
    override val id: String = "null"
    override val displayName: String = "None"
    override val messages: SharedFlow<ChatMessage> = MutableSharedFlow()
    override val connectionState: StateFlow<ChatConnectionState> =
        MutableStateFlow(ChatConnectionState.DISCONNECTED)
    override suspend fun connect(config: ChatProviderConfig) = Result.success(Unit)
    override suspend fun disconnect() {}
    override fun sendMessage(text: String) = false
}
