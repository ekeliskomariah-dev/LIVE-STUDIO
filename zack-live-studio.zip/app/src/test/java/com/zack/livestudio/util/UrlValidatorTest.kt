package com.zack.livestudio.util

import org.junit.Test
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull

class UrlValidatorTest {

    @Test fun rejects_null_and_blank() {
        assertFalse(UrlValidator.isHttpUrl(null))
        assertFalse(UrlValidator.isHttpUrl(""))
        assertFalse(UrlValidator.isHttpUrl("    "))
    }

    @Test fun accepts_http_and_https() {
        assertTrue(UrlValidator.isHttpUrl("https://www.youtube.com"))
        assertTrue(UrlValidator.isHttpUrl("http://example.com/path"))
        assertTrue(UrlValidator.isHttpUrl("https://sub.domain.co.id/page?q=1"))
    }

    @Test fun rejects_javascript_and_file_schemes() {
        assertFalse(UrlValidator.isHttpUrl("javascript:alert(1)"))
        assertFalse(UrlValidator.isHttpUrl("file:///etc/passwd"))
        assertFalse(UrlValidator.isHttpUrl("content://media/external"))
    }

    @Test fun rejects_malformed_urls() {
        assertFalse(UrlValidator.isHttpUrl("not-a-url"))
        assertFalse(UrlValidator.isHttpUrl("https://"))
        assertFalse(UrlValidator.isHttpUrl("https://no dot"))
        assertFalse(UrlValidator.isHttpUrl("https://" + "x".repeat(2049)))
    }

    @Test fun normalize_adds_https_scheme() {
        assertEquals("https://example.com", UrlValidator.normalize("example.com"))
        assertEquals("https://example.com", UrlValidator.normalize("https://example.com"))
    }

    @Test fun normalize_returns_null_for_garbage() {
        assertNull(UrlValidator.normalize(null))
        assertNull(UrlValidator.normalize(""))
        assertNull(UrlValidator.normalize("javascript:bad"))
    }

    @Test fun rtmp_validation() {
        assertTrue(UrlValidator.isValidRtmpUrl("rtmp://a.rtmp.youtube.com/live2"))
        assertTrue(UrlValidator.isValidRtmpUrl("rtmps://example.com:1935/live"))
        assertFalse(UrlValidator.isValidRtmpUrl("rtmp://"))
        assertFalse(UrlValidator.isValidRtmpUrl("https://example.com"))
        assertFalse(UrlValidator.isValidRtmpUrl("not a url"))
    }

    @Test fun stream_key_validation() {
        assertTrue(UrlValidator.isValidStreamKey("abcd-1234-efgh"))
        assertTrue(UrlValidator.isValidStreamKey("live_1234_abc"))
        assertFalse(UrlValidator.isValidStreamKey(null))
        assertFalse(UrlValidator.isValidStreamKey(""))
        assertFalse(UrlValidator.isValidStreamKey("ab")) // too short
        assertFalse(UrlValidator.isValidStreamKey("key with spaces"))
        assertFalse(UrlValidator.isValidStreamKey("a".repeat(300))) // too long
    }
}
