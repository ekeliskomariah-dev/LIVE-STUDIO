package com.zack.livestudio.streaming.rtmp

/**
 * Constants for RTMP message types used in this implementation.
 */
object MessageType {
    const val SET_CHUNK_SIZE = 1
    const val ABORT_MESSAGE = 2
    const val ACK = 3
    const val USER_CONTROL = 4
    const val WINDOW_ACK_SIZE = 5
    const val SET_PEER_BW = 6
    const val AUDIO_DATA = 8
    const val VIDEO_DATA = 9
    const val DATA_AMF3 = 15
    const val DATA_AMF0 = 16
    const val SHARED_OBJECT_AMF0 = 19
    const val COMMAND_AMF0 = 20
    const val COMMAND_AMF3 = 17
}

/**
 * Builds the FLV video tag header used by RTMP video messages for H.264 (AVC).
 *
 * The caller passes the encoded NALU payload and a flag indicating whether
 * this is the AVCDecoderConfigurationRecord (emitted by MediaCodec as the
 * first buffer with BUFFER_FLAG_CODEC_CONFIG). When [isConfig] is true we
 * set AVCPacketType=0 (sequence header); otherwise AVCPacketType=1 (NALU).
 *
 * Whether the frame is a keyframe is decided by [isKeyframe].
 *
 * FLV video tag byte layout:
 *   byte 0: FrameType (1 keyframe / 2 inter) << 4 | CodecID (7 = AVC)
 *   byte 1: AVCPacketType (0 = seq header, 1 = NALU, 2 = end)
 *   bytes 2-4: CompositionTime offset (24-bit BE)
 *   rest: payload
 */
object FlvTagWriter {

    fun videoHeader(payload: ByteArray, timestampMs: Int, isKeyframe: Boolean, isConfig: Boolean): ByteArray {
        if (payload.isEmpty()) return payload
        val frameType = if (isKeyframe || isConfig) 1 else 2
        val avcPacketType = if (isConfig) 0 else 1
        val out = java.io.ByteArrayOutputStream(payload.size + 5)
        out.write(((frameType and 0x0F) shl 4) or 7) // FrameType + CodecID=AVC
        out.write(avcPacketType and 0xFF)
        // CompositionTime (24-bit BE) — we always emit 0 because our encoder
        // is configured with realtime presentation timestamp equal to DTS.
        out.write(0); out.write(0); out.write(0)
        out.write(payload)
        return out.toByteArray()
    }

    /**
     * Builds the FLV audio tag header for AAC payloads.
     *
     * When [isConfig] is true we set the AACPacketType to 0 (AudioSpecificConfig);
     * otherwise 1 (raw AAC frame).
     *
     * SoundFormat=10 (AAC), SoundRate=3 (44kHz), SoundSize=1 (16-bit),
     * SoundType=1 (stereo). The actual sample rate / channel count are
     * signaled inside the AudioSpecificConfig; the FLV header byte is a
     * hint and most decoders tolerate a mismatch.
     */
    fun audioHeader(payload: ByteArray, timestampMs: Int, isConfig: Boolean): ByteArray {
        if (payload.isEmpty()) return payload
        val out = java.io.ByteArrayOutputStream(payload.size + 2)
        out.write(0xAF) // AAC, 44kHz, 16-bit, stereo
        out.write(if (isConfig) 0x00 else 0x01) // sequence header or raw frame
        out.write(payload)
        return out.toByteArray()
    }
}
