package com.zack.livestudio.overlay

import kotlinx.serialization.Serializable

/**
 * Logical layer in the scene. Coordinates are in normalized scene space
 * (0..1 in x, 0..1 in y), where (0,0) is the top-left corner. The width
 * and height are also normalized (1.0 = full scene size). Rotation is in
 * degrees (0..360) clockwise.
 *
 * This format is intentionally independent of the final stream resolution
 * so the same scene can be reused at 720p, 1080p, etc.
 */
@Serializable
data class LayerTransform(
    val x: Float = 0f,
    val y: Float = 0f,
    val width: Float = 1f,
    val height: Float = 1f,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val cornerRadiusPx: Int = 0,
    val borderWidthPx: Int = 0,
    val borderColor: String = "#00000000",
    val shadowEnabled: Boolean = false
)

@Serializable
data class LayerModel(
    val id: String,
    val type: LayerType,
    val name: String,
    val transform: LayerTransform = LayerTransform(),
    val payload: LayerPayload = LayerPayload.None,
    val zOrder: Int = 0
) {
    fun copy(transform: LayerTransform) = copy(transform = transform)
}

@Serializable
enum class LayerType {
    SCREEN, CAMERA, BROWSER, IMAGE, TEXT, CHAT, ALERT, BACKGROUND
}

@Serializable
sealed class LayerPayload {
    @Serializable
    data object None : LayerPayload()

    @Serializable
    data class Screen(val captureWidth: Int = 1280, val captureHeight: Int = 720) : LayerPayload()

    @Serializable
    data class Camera(val lensFacingFront: Boolean = true, val mirror: Boolean = true) : LayerPayload()

    @Serializable
    data class Browser(val url: String, val cssOverride: String = "") : LayerPayload()

    @Serializable
    data class Image(val uri: String, val mime: String = "image/png") : LayerPayload()

    @Serializable
    data class Text(
        val content: String,
        val fontFamily: String = "sans-serif",
        val fontSizeSp: Int = 32,
        val bold: Boolean = false,
        val italic: Boolean = false,
        val align: String = "left",          // left, center, right
        val letterSpacing: Float = 0f,
        val lineSpacing: Float = 1f,
        val color: String = "#FFFFFFFF",
        val strokeColor: String = "#00000000",
        val strokeWidth: Float = 0f,
        val shadowColor: String = "#00000000",
        val shadowRadius: Float = 0f,
        val backgroundColor: String = "#00000000",
        val roundedBackground: Boolean = false,
        val animation: String = "none"        // none, fade, slide, pop, typewriter, marquee
    ) : LayerPayload()

    @Serializable
    data class Chat(val providerId: String, val maxMessages: Int = 6, val fontSizeSp: Int = 14) : LayerPayload()

    @Serializable
    data class Alert(val sourceId: String, val displayMs: Int = 4000) : LayerPayload()

    @Serializable
    data class Background(val color: String = "#FF000000", val imageUri: String? = null) : LayerPayload()
}

@Serializable
data class Scene(
    val id: String,
    val name: String,
    val layers: List<LayerModel> = emptyList(),
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
) {
    fun sortedByZ(): List<LayerModel> = layers.sortedBy { it.zOrder }
    fun withLayer(layer: LayerModel): Scene = copy(
        layers = layers.map { if (it.id == layer.id) layer else it } + (if (layers.none { it.id == layer.id }) listOf(layer) else emptyList()),
        updatedAt = System.currentTimeMillis()
    )
}
