package com.zack.livestudio.streaming.rtmp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class RtmpUrlTest {

    @Test fun parses_youtube_style_url() {
        val p = RtmpUrl.parse("rtmp://a.rtmp.youtube.com/live2/abcd-1234")
        assertNotNull(p)
        assertEquals("a.rtmp.youtube.com", p!!.host)
        assertEquals(1935, p.port)
        assertEquals("live2", p.app)
        assertEquals("abcd-1234", p.streamKey)
    }

    @Test fun parses_twitch_style_url() {
        val p = RtmpUrl.parse("rtmp://live.twitch.tv/app/live_123_abc")
        assertNotNull(p)
        assertEquals("live.twitch.tv", p!!.host)
        assertEquals("app", p.app)
        assertEquals("live_123_abc", p.streamKey)
    }

    @Test fun parses_with_explicit_port() {
        val p = RtmpUrl.parse("rtmp://example.com:1935/live/stream1")
        assertNotNull(p)
        assertEquals(1935, p!!.port)
        assertEquals("live", p.app)
        assertEquals("stream1", p.streamKey)
    }

    @Test fun parses_no_stream_key() {
        val p = RtmpUrl.parse("rtmp://example.com/live")
        assertNotNull(p)
        assertEquals("live", p!!.app)
        assertNull(p.streamKey)
    }

    @Test fun rejects_https_url() {
        assertNull(RtmpUrl.parse("https://example.com/live"))
    }

    @Test fun rejects_garbage() {
        assertNull(RtmpUrl.parse("not a url"))
        assertNull(RtmpUrl.parse(""))
        assertNull(RtmpUrl.parse("rtmp://"))
    }

    @Test fun accepts_rtmps() {
        val p = RtmpUrl.parse("rtmps://example.com/live/stream1")
        assertNotNull(p)
        assertEquals("example.com", p!!.host)
    }

    @Test fun isvalid_returns_true_for_valid_urls() {
        assertTrue(RtmpUrl.isValid("rtmp://example.com/live"))
        assertFalse(RtmpUrl.isValid("https://example.com"))
    }
}
