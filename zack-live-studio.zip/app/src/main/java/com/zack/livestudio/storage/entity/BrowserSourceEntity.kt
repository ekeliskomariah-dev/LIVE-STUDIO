package com.zack.livestudio.storage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "browser_sources")
data class BrowserSourceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val createdAt: Long,
    val lastUsedAt: Long
)
