package com.zack.livestudio.overlay

import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotNull

class LayerModelTest {

    @Test fun new_scene_has_default_layer_transforms() {
        val t = LayerTransform()
        assertEquals(0f, t.x, 0.001f)
        assertEquals(0f, t.y, 0.001f)
        assertEquals(1f, t.width, 0.001f)
        assertEquals(1f, t.height, 0.001f)
        assertEquals(1f, t.opacity, 0.001f)
        assertTrue(t.visible)
    }

    @Test fun scene_withLayer_adds_when_missing() {
        val scene = Scene(
            id = "s1", name = "Test",
            layers = emptyList(),
            createdAt = 0, updatedAt = 0
        )
        val layer = LayerModel(
            id = "L1", type = LayerType.TEXT, name = "Hello",
            transform = LayerTransform(), payload = LayerPayload.None, zOrder = 1
        )
        val updated = scene.withLayer(layer)
        assertEquals(1, updated.layers.size)
        assertEquals("L1", updated.layers.first().id)
    }

    @Test fun scene_withLayer_replaces_existing() {
        val scene = Scene(
            id = "s1", name = "Test",
            layers = listOf(LayerModel(
                id = "L1", type = LayerType.TEXT, name = "Hello",
                transform = LayerTransform(x = 0.1f),
                payload = LayerPayload.None, zOrder = 1
            )),
            createdAt = 0, updatedAt = 0
        )
        val layer = LayerModel(
            id = "L1", type = LayerType.TEXT, name = "Hello",
            transform = LayerTransform(x = 0.5f),
            payload = LayerPayload.None, zOrder = 1
        )
        val updated = scene.withLayer(layer)
        assertEquals(1, updated.layers.size)
        assertEquals(0.5f, updated.layers.first().transform.x, 0.001f)
    }

    @Test fun sortedByZ_sorts_ascending() {
        val scene = Scene(
            id = "s1", name = "Test",
            layers = listOf(
                LayerModel("a", LayerType.IMAGE, "a", zOrder = 30),
                LayerModel("b", LayerType.TEXT, "b", zOrder = 10),
                LayerModel("c", LayerType.CAMERA, "c", zOrder = 20)
            ),
            createdAt = 0, updatedAt = 0
        )
        val sorted = scene.sortedByZ()
        assertEquals(listOf("b", "c", "a"), sorted.map { it.id })
    }
}
