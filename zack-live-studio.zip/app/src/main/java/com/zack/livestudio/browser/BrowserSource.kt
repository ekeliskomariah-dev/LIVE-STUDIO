package com.zack.livestudio.browser

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.zack.livestudio.util.AppLog
import com.zack.livestudio.util.UrlValidator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayInputStream

/**
 * Represents a single browser source. The user supplies a URL; we load it
 * inside a headless WebView and capture the rendered frames to a bitmap
 * which the compositor then uploads as a GL texture.
 *
 * SECURITY:
 *  - We NEVER enable file access from WebView.
 *  - We NEVER add a JavascriptInterface unless explicitly configured by user.
 *  - We respect X-Frame-Options / CSP — if the site refuses embedding we
 *    surface a clear error message and offer "Open in Browser" instead.
 *  - We never bypass authentication.
 */
class BrowserSource(
    private val context: Context,
    private val id: String,
    private val initialUrl: String,
    private val onBitmap: (String, Bitmap) -> Unit,
    private val onError: (String, BrowserSourceError) -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private val captureHandler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    @Volatile private var loaded = false
    private val _state = MutableStateFlow(BrowserSourceState.IDLE)
    val state: StateFlow<BrowserSourceState> = _state

    @SuppressLint("SetJavaScriptEnabled")
    fun start(widthPx: Int, heightPx: Int) {
        if (!UrlValidator.isHttpUrl(initialUrl)) {
            _state.value = BrowserSourceState.INVALID_URL
            onError(id, BrowserSourceError.InvalidUrl(initialUrl))
            return
        }
        handler.post {
            try {
                val wv = WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(widthPx, heightPx)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportZoom(false)
                    settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
                        WebSettingsCompat.setSafeBrowsingEnabled(settings, true)
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            _state.value = BrowserSourceState.LOADING
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            loaded = true
                            _state.value = BrowserSourceState.LOADED
                            startCaptureLoop()
                        }

                        override fun onReceivedError(
                            view: WebView?, request: WebResourceRequest?,
                            error: WebResourceError
                        ) {
                            AppLog.w(TAG, "[$id] Web error: ${error.description}")
                            if (request?.isForMainFrame == true) {
                                _state.value = BrowserSourceState.FAILED
                                onError(id, BrowserSourceError.EmbeddingRefused(error.description.toString()))
                            }
                        }

                        override fun onReceivedHttpError(
                            view: WebView?, request: WebResourceRequest?,
                            errorResponse: WebResourceResponse
                        ) {
                            val code = errorResponse.statusCode
                            AppLog.w(TAG, "[$id] HTTP $code")
                            if (code == 403 || code == 401) {
                                _state.value = BrowserSourceState.FAILED
                                onError(id, BrowserSourceError.EmbeddingRefused("HTTP $code — site refused embedding"))
                            }
                        }
                    }
                    loadUrl(initialUrl)
                }
                webView = wv
            } catch (e: Exception) {
                AppLog.e(TAG, "[$id] WebView creation failed: ${e.message}")
                _state.value = BrowserSourceState.FAILED
                onError(id, BrowserSourceError.WebviewFailed(e.message ?: "Unknown"))
            }
        }
    }

    private fun startCaptureLoop() {
        // Capture ~15-20 FPS — enough for donation alerts / chat overlays.
        // We intentionally don't push higher because WebView rasterization
        // is expensive and stream viewers won't notice for static widgets.
        val captureRunnable = object : Runnable {
            override fun run() {
                val wv = webView ?: return
                if (!loaded) return
                if (wv.width <= 0 || wv.height <= 0) return
                val bmp = Bitmap.createBitmap(wv.width, wv.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                try {
                    wv.draw(canvas)
                    onBitmap(id, bmp)
                } catch (e: Exception) {
                    AppLog.w(TAG, "[$id] capture failed: ${e.message}")
                    bmp.recycle()
                }
                captureHandler.postDelayed(this, 50L) // ~20 FPS
            }
        }
        captureHandler.post(captureRunnable)
    }

    fun refresh() {
        handler.post { webView?.reload() }
    }

    fun stop() {
        captureHandler.removeCallbacksAndMessages(null)
        handler.post {
            try { (webView?.parent as? ViewGroup)?.removeView(webView) } catch (_: Exception) {}
            webView?.apply {
                stopLoading()
                loadUrl("about:blank")
                onPause()
                destroy()
            }
            webView = null
        }
        loaded = false
        _state.value = BrowserSourceState.IDLE
    }

    companion object {
        private const val TAG = "BrowserSource"
    }
}

enum class BrowserSourceState { IDLE, LOADING, LOADED, FAILED, INVALID_URL }

sealed class BrowserSourceError {
    data class InvalidUrl(val url: String) : BrowserSourceError()
    data class EmbeddingRefused(val reason: String) : BrowserSourceError()
    data class WebviewFailed(val reason: String) : BrowserSourceError()
}
