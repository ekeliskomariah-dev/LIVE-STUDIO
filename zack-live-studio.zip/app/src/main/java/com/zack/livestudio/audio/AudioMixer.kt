package com.zack.livestudio.audio

import com.zack.livestudio.streaming.StreamConfig
import com.zack.livestudio.util.AppLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.nio.ByteBuffer
import java.nio.ShortBuffer

/**
 * Mixes multiple PCM sources (mic, internal audio, browser audio, game audio)
 * into a single output stream that is then fed to the AAC encoder.
 *
 * Mixing strategy: weighted sum clamped to 16-bit range. Per-source
 * volume/mute is applied before mixing.
 *
 * Buffering: we maintain a single growing output buffer that accumulates
 * samples; the encoder consumes the available bytes each tick. This avoids
 * frame drops when sources are slightly out of sync.
 */
class AudioMixer(
    private val config: StreamConfig
) {
    enum class Source { MICROPHONE, INTERNAL, BROWSER, GAME }

    private val volumes = mutableMapOf<Source, Float>().apply {
        Source.values().forEach { put(it, 1.0f) }
    }
    private val muted = mutableMapOf<Source, Boolean>().apply {
        Source.values().forEach { put(it, false) }
    }

    private val buffers = mutableMapOf<Source, ArrayDeque<ByteArray>>()

    private val _outputLevelDb = MutableStateFlow(-100f)
    val outputLevelDb: StateFlow<Float> = _outputLevelDb

    @Synchronized
    fun submit(source: Source, pcm: ByteArray) {
        val dq = buffers.getOrPut(source) { ArrayDeque() }
        dq.addLast(pcm)
        // Cap buffer to ~200ms of audio (16-bit stereo @ 44.1k = 176KB/s, so ~35KB)
        val maxBytes = (config.audioSampleRateHz * 2 * config.audioChannelCount * 0.2).toInt()
        var total = dq.sumOf { it.size }
        while (total > maxBytes && dq.isNotEmpty()) {
            dq.removeFirst()
            total = dq.sumOf { it.size }
        }
    }

    @Synchronized
    fun setVolume(source: Source, vol: Float) {
        volumes[source] = vol.coerceIn(0f, 2f)
    }

    @Synchronized
    fun setMuted(source: Source, muted: Boolean) {
        this.muted[source] = muted
    }

    @Synchronized
    fun isMuted(source: Source): Boolean = muted[source] ?: false

    /**
     * Drain mixed PCM. Returns up to [maxBytes] of mixed audio.
     */
    @Synchronized
    fun drain(maxBytes: Int): ByteArray {
        if (buffers.isEmpty()) return ByteArray(0)
        val channels = config.audioChannelCount.coerceAtLeast(1)
        val frameSize = 2 * channels
        val outFrames = (maxBytes / frameSize)
        val outBytes = outFrames * frameSize
        if (outBytes == 0) return ByteArray(0)

        val mixed = ShortArray(outFrames * channels)
        var totalAbs = 0L
        var totalSamples = 0

        for ((src, dq) in buffers.toList()) {
            val v = if (muted[src] == true) 0f else (volumes[src] ?: 1f)
            if (v == 0f) continue
            var pos = 0
            while (pos < outBytes && dq.isNotEmpty()) {
                val buf = dq.peekFirst() ?: break
                val sb = ByteBuffer.wrap(buf).asShortBuffer()
                val copy = minOf(sb.remaining(), (outBytes - pos) / 2)
                for (i in 0 until copy) {
                    val idx = pos / 2 + i
                    if (idx >= mixed.size) break
                    val s = sb.get()
                    val m = (s * v).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                    val cur = mixed[idx].toInt()
                    val merged = cur + m
                    mixed[idx] = merged.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                    totalAbs += Math.abs(m)
                    totalSamples++
                }
                val consumed = copy * 2
                if (consumed >= buf.size) dq.removeFirst()
                else {
                    // Truncate the head of the remaining buffer
                    val newBuf = ByteArray(buf.size - consumed)
                    System.arraycopy(buf, consumed, newBuf, 0, newBuf.size)
                    dq.removeFirst()
                    dq.addFirst(newBuf)
                }
                pos += consumed
            }
            if (dq.isEmpty()) buffers.remove(src)
        }

        if (totalSamples > 0) {
            val avg = totalAbs.toFloat() / totalSamples
            val db = (20f * Math.log10((avg / 32767f).coerceAtLeast(1e-6f))).toFloat()
            _outputLevelDb.value = db
        } else {
            _outputLevelDb.value = -100f
        }

        val out = ByteArray(outBytes)
        ByteBuffer.wrap(out).asShortBuffer().put(mixed)
        return out
    }

    @Synchronized
    fun reset() {
        buffers.clear()
        _outputLevelDb.value = -100f
    }
}
