package com.zack.livestudio.alerts

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * A single alert event. The data class is intentionally minimal — the
 * visual representation (image, animation, sound) is decided by the Alert
 * layer in the scene, not by the event itself.
 *
 * For browser-based alert providers (Sociabuzz / Saweria / Trakteer /
 * custom webhook), the integration is via the user adding a browser
 * source pointing at the provider's alert page — exactly as recommended
 * in the spec. This file handles *programmatic* alert events emitted by
 * chat providers or webhooks configured by the user.
 */
data class AlertEvent(
    val id: String,
    val type: AlertType,
    val username: String,
    val message: String = "",
    val amount: Double = 0.0,
    val currency: String = "USD",
    val imageUrl: String? = null,
    val soundUrl: String? = null,
    val timestampMs: Long = System.currentTimeMillis(),
    val metadata: Map<String, String> = emptyMap()
)

enum class AlertType { DONATION, FOLLOW, SUBSCRIBER, CUSTOM }

/**
 * Shared event bus. The chat provider, a webhook receiver, or a browser
 * bridge all post events here. The alert layer in the active scene
 * subscribes to this flow and renders events as they arrive.
 */
object AlertBus {
    private val _events = MutableSharedFlow<AlertEvent>(replay = 0, extraBufferCapacity = 16)
    val events: SharedFlow<AlertEvent> = _events.asSharedFlow()

    suspend fun emit(event: AlertEvent) { _events.emit(event) }

    fun tryEmit(event: AlertEvent): Boolean = _events.tryEmit(event)
}
