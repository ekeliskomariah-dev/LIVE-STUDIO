package com.zack.livestudio.streaming

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class ReconnectManagerTest {

    @Test
    fun reports_failure_after_max_attempts() = runTest {
        val statuses = mutableListOf<ReconnectManager.ReconnectStatus>()
        val mgr = ReconnectManager(
            scope = this,
            maxAttempts = 3,
            baseDelayMs = 1L,
            maxDelayMs = 5L,
            onStatus = { statuses += it },
            tryReconnect = { false }
        )
        mgr.start()
        // yield to allow job to complete
        repeat(20) { kotlinx.coroutines.yield() }
        kotlinx.coroutines.delay(50)
        assertEquals(ReconnectManager.ReconnectStatus.Failed, statuses.last())
    }
}
