package com.zack.livestudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.zack.livestudio.R
import com.zack.livestudio.scenes.SceneTemplates
import com.zack.livestudio.overlay.Scene
import com.zack.livestudio.ui.components.EmptyState
import com.zack.livestudio.ui.components.GlassPanel
import com.zack.livestudio.ui.theme.NeonBlue
import com.zack.livestudio.ui.theme.NeonPurple

@Composable
fun ScenesScreen(navController: NavController, vm: ScenesViewModel = viewModel()) {
    val scenes by vm.scenes.collectAsState(emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.nav_scenes), fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { vm.showCreateDialog = true },
                containerColor = NeonBlue,
                contentColor = Color.White
            ) {
                Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.scene_action_new))
            }
        }
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(MaterialTheme.colorScheme.background)
        ) {
            if (scenes.isEmpty()) {
                EmptyState(
                    title = stringResource(R.string.empty_scenes),
                    hint = stringResource(R.string.empty_scenes_hint)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(scenes, key = { it.id }) { scene ->
                        SceneCard(scene = scene, onRename = { vm.rename(it) },
                            onDuplicate = { vm.duplicate(it) },
                            onDelete = { vm.delete(it) })
                    }
                }
            }
        }
    }

    if (vm.showCreateDialog) {
        SceneTemplatePicker(
            onPick = { name ->
                vm.createFromTemplate(name)
                vm.showCreateDialog = false
            },
            onDismiss = { vm.showCreateDialog = false }
        )
    }
}

@Composable
private fun SceneCard(
    scene: Scene,
    onRename: (Scene) -> Unit,
    onDuplicate: (Scene) -> Unit,
    onDelete: (Scene) -> Unit
) {
    GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(scene.name, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
                Text("${scene.layers.size} layers", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { onRename(scene) }) {
                Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.scene_action_rename),
                    tint = NeonBlue)
            }
            IconButton(onClick = { onDuplicate(scene) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = stringResource(R.string.scene_action_duplicate),
                    tint = NeonPurple)
            }
            IconButton(onClick = { onDelete(scene) }) {
                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.scene_action_delete),
                    tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun SceneTemplatePicker(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text(stringResource(R.string.scene_action_new)) },
        text = {
            Column {
                listOf("Gaming", "Just Chatting", "Starting Soon", "BRB", "Ending", "Custom").forEach { name ->
                    Text(
                        text = name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    )
}
