package com.zack.livestudio.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zack.livestudio.overlay.Scene
import com.zack.livestudio.scenes.SceneRepository
import com.zack.livestudio.scenes.SceneSerializer
import com.zack.livestudio.scenes.SceneTemplates
import com.zack.livestudio.storage.ZackDatabase
import com.zack.livestudio.storage.entity.SceneEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class ScenesViewModel : ViewModel() {
    var showCreateDialog by mutableStateOf(false)
    private val _scenes = MutableStateFlow<List<Scene>>(emptyList())
    val scenes: StateFlow<List<Scene>> = _scenes.asStateFlow()

    private var repo: SceneRepository? = null

    fun bind(context: android.content.Context) {
        if (repo != null) return
        val dao = ZackDatabase.get(context).sceneDao()
        repo = SceneRepository(dao)
        viewModelScope.launch {
            repo!!.observeAll().collect { entities ->
                _scenes.value = entities.mapNotNull { SceneSerializer.deserialize(it.json) }
            }
        }
    }

    fun createFromTemplate(name: String) {
        val scene = SceneTemplates.fromTemplate(name)
        _scenes.value = _scenes.value + scene
        viewModelScope.launch { repo?.save(scene) }
    }

    fun rename(scene: Scene) { /* UI dialog dispatch — placeholder */ }
    fun duplicate(scene: Scene) {
        val copy = scene.copy(id = UUID.randomUUID().toString(),
            name = "${scene.name} copy",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis())
        _scenes.value = _scenes.value + copy
        viewModelScope.launch { repo?.save(copy) }
    }

    fun delete(scene: Scene) {
        _scenes.value = _scenes.value.filterNot { it.id == scene.id }
        viewModelScope.launch { repo?.delete(scene.id) }
    }
}
