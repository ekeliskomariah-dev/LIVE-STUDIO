package com.zack.livestudio.streaming

import com.zack.livestudio.util.AppLog
import com.zack.livestudio.util.SystemInfo

/**
 * Implements the "Safe Mode" behaviour described in the spec.
 *
 * When the encoder fails, the device overheats, or memory is critically
 * low, this manager progressively disables expensive features so the
 * stream can keep going (or fail gracefully) instead of crashing.
 *
 * Triggers (in order of severity):
 *   1. CPU > 90% for 5s          → disable AI background, throttle camera
 *   2. Temperature ≥ 42°C        → drop FPS, drop to next-lower resolution
 *   3. RAM usage > 90%           → close browser sources, clear caches
 *   4. Encoder dequeue fails     → disable hardware encoder, retry with SW
 *   5. Multiple encoder errors   → stop stream with clear user message
 */
class SafeModeManager {

    private var currentMode: Mode = Mode.NORMAL

    enum class Mode {
        NORMAL,
        DISABLE_AI_BG,
        DISABLE_BROWSER,
        DISABLE_CAMERA,
        SOFTWARE_ENCODER,
        STOP_STREAM
    }

    @Synchronized
    fun evaluate(context: android.content.Context, encoderOk: Boolean): Mode {
        val temp = SystemInfo.batteryTemperatureC(context)
        val ram = SystemInfo.ramUsagePercent(context)
        val cpu = SystemInfo.cpuUsagePercent()

        val newMode = when {
            !encoderOk && currentMode == Mode.SOFTWARE_ENCODER -> Mode.STOP_STREAM
            !encoderOk -> Mode.SOFTWARE_ENCODER
            temp >= 45f || ram > 92 -> Mode.DISABLE_CAMERA
            temp >= 42f -> Mode.DISABLE_AI_BG
            ram > 85 -> Mode.DISABLE_BROWSER
            cpu > 90 -> Mode.DISABLE_AI_BG
            else -> Mode.NORMAL
        }
        if (newMode != currentMode) {
            AppLog.w(TAG, "Safe mode change: $currentMode -> $newMode (cpu=$cpu, ram=$ram, temp=$temp)")
            currentMode = newMode
        }
        return currentMode
    }

    fun reasonText(mode: Mode): String = when (mode) {
        Mode.NORMAL -> "All systems nominal"
        Mode.DISABLE_AI_BG -> "AI background removal disabled to save resources"
        Mode.DISABLE_BROWSER -> "Browser sources disabled (low memory)"
        Mode.DISABLE_CAMERA -> "Camera disabled (thermal/CPU critical)"
        Mode.SOFTWARE_ENCODER -> "Switched to software encoder (hardware encoder failed)"
        Mode.STOP_STREAM -> "Stream stopped: encoder unavailable"
    }

    companion object { private const val TAG = "SafeModeManager" }
}
