package com.zack.livestudio.chat

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * A chat message from a streaming platform. Platform-specific extras
 * (badges, colors, emotes) live in [metadata] as a flat string map so
 * the same data class is used across providers.
 */
data class ChatMessage(
    val id: String,
    val provider: String,
    val username: String,
    val avatarUrl: String? = null,
    val text: String,
    val timestampMs: Long,
    val color: String? = null,
    val isSubscriber: Boolean = false,
    val isModerator: Boolean = false,
    val metadata: Map<String, String> = emptyMap()
)

/**
 * Implementations of this interface connect to a live chat platform and
 * stream [ChatMessage] events via [messages].
 *
 * The interface intentionally avoids platform-specific types so we can
 * add new providers without touching the UI. We DO NOT scrape chat
 * pages — that violates most platforms' ToS and would also be unreliable.
 * Instead we use either the platform's official chat API (when one is
 * available and the user has provided credentials) or a custom WebSocket
 * endpoint chosen by the user.
 */
interface ChatProvider {
    val id: String
    val displayName: String
    val messages: SharedFlow<ChatMessage>
    val connectionState: Flow<ChatConnectionState>
    suspend fun connect(config: ChatProviderConfig): Result<Unit>
    suspend fun disconnect()
    fun sendMessage(text: String): Boolean     // returns false if provider doesn't support sending
}

enum class ChatConnectionState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class ChatProviderConfig(
    val endpoint: String,
    val authToken: String? = null,   // never logged, only stored in SecureStorage
    val channelId: String? = null,
    val extras: Map<String, String> = emptyMap()
)

/**
 * Built-in registry of chat providers. New providers register themselves
 * here so the UI can enumerate them at runtime.
 */
object ChatProviderRegistry {
    private val builders = mutableMapOf<String, () -> ChatProvider>()

    fun register(id: String, builder: () -> ChatProvider) {
        builders[id] = builder
    }

    fun create(id: String): ChatProvider? = builders[id]?.invoke()
    fun allProviderIds(): List<String> = builders.keys.toList()
}

/**
 * Shared bus that emits moderation events (hide, ban, filter) so the
 * chat overlay layer can react in real time without coupling to specific
 * provider implementations.
 */
object ChatModerationBus {
    private val _events = MutableSharedFlow<ModerationEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<ModerationEvent> = _events.asSharedFlow()

    suspend fun emit(event: ModerationEvent) { _events.emit(event) }
}

sealed class ModerationEvent {
    data class HideMessage(val messageId: String) : ModerationEvent()
    data class BlockUser(val userId: String) : ModerationEvent()
    data class BlockWord(val word: String) : ModerationEvent()
}
