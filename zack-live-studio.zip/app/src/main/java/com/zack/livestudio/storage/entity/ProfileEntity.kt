package com.zack.livestudio.storage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val platform: String,           // YOUTUBE / TWITCH / TIKTOK / CUSTOM_RTMP
    val rtmpUrl: String,
    val streamKeyRef: String,       // reference to SecureStorage
    val resolution: String,         // 480p / 720p / 1080p
    val fps: Int,
    val bitrateKbps: Int,
    val audioBitrateKbps: Int,
    val performanceMode: String,
    val preset: String,
    val createdAt: Long,
    val updatedAt: Long
)
