package com.zack.livestudio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zack.livestudio.ui.theme.LiveRed
import com.zack.livestudio.ui.theme.NeonBlue
import com.zack.livestudio.ui.theme.NeonCyan
import com.zack.livestudio.ui.theme.NeonPurple
import com.zack.livestudio.ui.theme.PanelColor

/**
 * Glass card surface used throughout the app. Subtle border + gradient
 * background gives the "modern creator SaaS" feel without overwhelming.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                    )
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(contentPadding)
    ) { content() }
}

/**
 * The big gradient START LIVE button — the most prominent control in the
 * studio screen.
 */
@Composable
fun NeonGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isStop: Boolean = false
) {
    val brush = if (isStop) SolidColor(LiveRed)
        else Brush.horizontalGradient(listOf(NeonBlue, NeonPurple, NeonCyan))
    val textColor = if (isStop) Color.White else Color.White
    androidx.compose.material3.Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(56.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(28.dp),
        contentPadding = PaddingValues(horizontal = 28.dp, vertical = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .background(brush, RoundedCornerShape(28.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = textColor, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
fun StatChip(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    accent: Color = NeonBlue
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .background(PanelColor, RoundedCornerShape(10.dp))
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Box(
            Modifier.size(8.dp).background(accent, RoundedCornerShape(4.dp))
        )
        Spacer(Modifier.width(8.dp))
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        Spacer(Modifier.width(8.dp))
        Text(value, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}
