package com.zack.livestudio.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zack.livestudio.chat.ChatMessage
import com.zack.livestudio.chat.NullChatProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val provider = NullChatProvider()

    init {
        viewModelScope.launch {
            provider.messages.collect { msg ->
                _messages.value = (_messages.value + msg).takeLast(500)
            }
        }
    }
}
