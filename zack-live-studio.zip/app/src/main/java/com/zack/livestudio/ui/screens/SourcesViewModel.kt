package com.zack.livestudio.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zack.livestudio.browser.BrowserSourceState
import com.zack.livestudio.storage.ZackDatabase
import com.zack.livestudio.storage.entity.BrowserSourceEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class SourceUiItem(
    val id: String,
    val name: String,
    val url: String,
    val state: BrowserSourceState
)

class SourcesViewModel : ViewModel() {
    private val _sources = MutableStateFlow<List<SourceUiItem>>(emptyList())
    val sources: StateFlow<List<SourceUiItem>> = _sources.asStateFlow()

    private var dao: com.zack.livestudio.storage.dao.BrowserSourceDao? = null

    fun bind(context: android.content.Context) {
        if (dao != null) return
        dao = ZackDatabase.get(context).browserSourceDao()
        viewModelScope.launch {
            dao!!.observeAll().collect { entities ->
                _sources.value = entities.map { SourceUiItem(it.id, it.name, it.url, BrowserSourceState.IDLE) }
            }
        }
    }

    fun add(name: String, url: String) {
        val entity = BrowserSourceEntity(
            id = UUID.randomUUID().toString(),
            name = name,
            url = url,
            createdAt = System.currentTimeMillis(),
            lastUsedAt = System.currentTimeMillis()
        )
        viewModelScope.launch { dao?.upsert(entity) }
    }

    fun refresh(id: String) { /* delegate to service bus */ }
    fun delete(id: String) {
        viewModelScope.launch {
            val entity = _sources.value.firstOrNull { it.id == id } ?: return@launch
            dao?.delete(BrowserSourceEntity(
                id = entity.id, name = entity.name, url = entity.url,
                createdAt = 0L, lastUsedAt = 0L
            ))
        }
    }
}
