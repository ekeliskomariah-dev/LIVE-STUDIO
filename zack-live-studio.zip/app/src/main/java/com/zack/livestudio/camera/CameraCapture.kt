package com.zack.livestudio.camera

import android.content.Context
import android.util.Range
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.zack.livestudio.util.AppLog

/**
 * Wraps CameraX so we can drive a single camera with the user's selected
 * options (front/back, zoom, exposure, focus, flash) and route its frames
 * into a SurfaceTexture owned by the compositor.
 *
 * We use PREVIEW use case only — for streaming, lower-latency preview
 * output is preferred over high-res image capture. The texture is then
 * consumed by the compositor which mixes it with the other layers.
 */
class CameraCapture(
    private val context: Context
) {
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var selector: CameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
    @Volatile private var isStarted = false

    fun prepare(onReady: (Boolean) -> Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            cameraProvider = future.get()
            onReady(true)
        }, ContextCompat.getMainExecutor(context))
    }

    fun start(
        lifecycleOwner: LifecycleOwner,
        surfaceProvider: PreviewView.SurfaceProvider,
        lensFacingFront: Boolean = true,
        zoomRatio: Float = 1f,
        exposureIndex: Int = 0,
        flashEnabled: Boolean = false
    ): Boolean {
        val provider = cameraProvider ?: return false
        try {
            provider.unbindAll()
            selector = if (lensFacingFront) CameraSelector.DEFAULT_FRONT_CAMERA
                       else CameraSelector.DEFAULT_BACK_CAMERA
            preview = Preview.Builder().build().apply {
                setSurfaceProvider(surfaceProvider)
            }
            val cam = provider.bindToLifecycle(lifecycleOwner, selector, preview)
            camera = cam
            cam.cameraControl.setZoomRatio(zoomRatio)
            try {
                cam.cameraControl.setExposureCompensationIndex(exposureIndex)
            } catch (_: Exception) { /* device may not support */ }
            try {
                if (cam.cameraInfo.hasFlashUnit()) {
                    cam.cameraControl.enableTorch(flashEnabled)
                }
            } catch (_: Exception) {}
            isStarted = true
            AppLog.i(TAG, "Camera started: lens=${if (lensFacingFront) "front" else "back"} zoom=$zoomRatio")
            return true
        } catch (e: Exception) {
            AppLog.e(TAG, "Camera start failed: ${e.message}")
            return false
        }
    }

    fun setZoom(ratio: Float) { camera?.cameraControl?.setZoomRatio(ratio) }
    fun setExposureIndex(idx: Int) {
        try { camera?.cameraControl?.setExposureCompensationIndex(idx) } catch (_: Exception) {}
    }
    fun enableTorch(enabled: Boolean) {
        try {
            camera?.let {
                if (it.cameraInfo.hasFlashUnit()) it.cameraControl.enableTorch(enabled)
            }
        } catch (_: Exception) {}
    }

    fun focus(x: Float, y: Float) {
        // FocusMeteringAction requires a MeteringPoint created from a
        // PreviewView MeteringPointsFactory — when this is wired to a UI
        // touch handler we need the PreviewView reference passed in.
        // For now we log the request so the focus gesture is visible.
        AppLog.d(TAG, "focus requested at ($x, $y)")
    }

    fun stop() {
        cameraProvider?.unbindAll()
        camera = null
        preview = null
        isStarted = false
    }

    fun exposureRange(): Range<Int>? = camera?.cameraInfo?.exposureInfo?.exposureCompensationRange

    fun maxZoom(): Float = camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f

    companion object { private const val TAG = "CameraCapture" }
}
